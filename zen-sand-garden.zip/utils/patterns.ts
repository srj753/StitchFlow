import { BezierCurve, Point, ZenPatternMode } from '../types';
import { SeededRandom } from './math';

const RNG = new SeededRandom(42);

/**
 * Generates a standard flowing river pattern (horizontal waves).
 */
const generateFlowPattern = (width: number, height: number, density: number): BezierCurve[] => {
  const curves: BezierCurve[] = [];
  const spacing = density;
  const rows = Math.ceil(height / spacing) + 2;

  for (let i = -2; i < rows; i++) {
    const yBase = i * spacing;
    // Add some organic variance to the start/end points
    const startY = yBase + RNG.range(-5, 5);
    const endY = yBase + RNG.range(-5, 5);
    
    // Control points determine the wave
    const cp1Y = yBase - RNG.range(20, 100);
    const cp2Y = yBase + RNG.range(20, 100);

    curves.push({
      start: { x: -50, y: startY },
      cp1: { x: width * 0.3, y: cp1Y },
      cp2: { x: width * 0.7, y: cp2Y },
      end: { x: width + 50, y: endY },
    });
  }
  return curves;
};

/**
 * Generates gentle sine waves.
 */
const generateWavePattern = (width: number, height: number, density: number): BezierCurve[] => {
  const curves: BezierCurve[] = [];
  const spacing = density;
  const rows = Math.ceil(height / spacing) + 2;

  for (let i = -2; i < rows; i++) {
    const yBase = i * spacing;
    
    curves.push({
      start: { x: -50, y: yBase },
      cp1: { x: width * 0.33, y: yBase + 100 },
      cp2: { x: width * 0.66, y: yBase - 100 },
      end: { x: width + 50, y: yBase },
    });
  }
  return curves;
};

/**
 * Generates concentric circles simulating a stone dropped in sand.
 */
const generateConcentricPattern = (width: number, height: number, density: number): BezierCurve[] => {
  const curves: BezierCurve[] = [];
  const centerX = width / 2;
  const centerY = height / 2;
  const maxRadius = Math.sqrt(width * width + height * height) * 0.6;
  const count = Math.ceil(maxRadius / density);

  for (let i = 1; i < count; i++) {
    const r = i * density;
    const kappa = 0.55228474983; // Constant for circle approximation with Bezier
    const ox = r * kappa; // offset
    const oy = r * kappa;

    // A circle needs 4 curves
    // Top Right
    curves.push({
      start: { x: centerX, y: centerY - r },
      cp1: { x: centerX + ox, y: centerY - r },
      cp2: { x: centerX + r, y: centerY - oy },
      end: { x: centerX + r, y: centerY }
    });
    // Bottom Right
    curves.push({
      start: { x: centerX + r, y: centerY },
      cp1: { x: centerX + r, y: centerY + oy },
      cp2: { x: centerX + ox, y: centerY + r },
      end: { x: centerX, y: centerY + r }
    });
    // Bottom Left
    curves.push({
      start: { x: centerX, y: centerY + r },
      cp1: { x: centerX - ox, y: centerY + r },
      cp2: { x: centerX - r, y: centerY + oy },
      end: { x: centerX - r, y: centerY }
    });
    // Top Left
    curves.push({
      start: { x: centerX - r, y: centerY },
      cp1: { x: centerX - r, y: centerY - oy },
      cp2: { x: centerX - ox, y: centerY - r },
      end: { x: centerX, y: centerY - r }
    });
  }

  return curves;
};

const generateSpiralPattern = (width: number, height: number, density: number): BezierCurve[] => {
    const curves: BezierCurve[] = [];
    const centerX = width / 2;
    const centerY = height / 2;
    const maxRadius = Math.max(width, height) * 0.8;
    
    // Create a spiral using approximations of arcs
    let currentRadius = 10;
    let angle = 0;
    
    while(currentRadius < maxRadius) {
        const startX = centerX + Math.cos(angle) * currentRadius;
        const startY = centerY + Math.sin(angle) * currentRadius;
        
        angle += Math.PI / 2;
        currentRadius += density / 1.5; // Expand radius
        
        const endX = centerX + Math.cos(angle) * currentRadius;
        const endY = centerY + Math.sin(angle) * currentRadius;
        
        // Control point approximation for 90 degree arc
        // This is a rough approximation to make it look organic rather than perfect math
        const cpRadius = currentRadius - (density/3); 
        const cpAngle = angle - Math.PI/4;
        
        curves.push({
            start: { x: startX, y: startY },
            cp1: { x: startX + (Math.cos(angle-Math.PI/2) * density), y: startY + (Math.sin(angle-Math.PI/2) * density) },
            cp2: { x: endX + (Math.cos(angle) * -density/2), y: endY + (Math.sin(angle) * -density/2) },
            end: { x: endX, y: endY }
        });
    }

    return curves;
}

export const generatePaths = (
  width: number, 
  height: number, 
  mode: ZenPatternMode, 
  density: number = 14
): BezierCurve[] => {
  switch (mode) {
    case ZenPatternMode.CONCENTRIC:
      return generateConcentricPattern(width, height, density);
    case ZenPatternMode.WAVE:
      return generateWavePattern(width, height, density);
    case ZenPatternMode.SPIRAL:
        return generateSpiralPattern(width, height, density);
    case ZenPatternMode.FLOW:
    default:
      return generateFlowPattern(width, height, density);
  }
};