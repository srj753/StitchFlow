
// Simple seeded PRNG to ensure patterns are reproducible but organic
export class SeededRandom {
  private seed: number;

  constructor(seed: number = 12345) {
    this.seed = seed;
  }

  // Linear Congruential Generator
  next(): number {
    this.seed = (this.seed * 1664525 + 1013904223) % 4294967296;
    return this.seed / 4294967296;
  }

  range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }
}

// Cubic Ease-in-out for smooth animations
export const easeInOutCubic = (t: number): number => {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
};

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export const lerpPoint = (p1: {x:number, y:number}, p2: {x:number, y:number}, t: number) => ({
  x: lerp(p1.x, p2.x, t),
  y: lerp(p1.y, p2.y, t)
});

export const getDistance = (p1: {x:number, y:number}, p2: {x:number, y:number}) => {
  const dx = p1.x - p2.x;
  const dy = p1.y - p2.y;
  return Math.sqrt(dx * dx + dy * dy);
};

export const getAngle = (p1: {x:number, y:number}, p2: {x:number, y:number}) => {
  return Math.atan2(p2.y - p1.y, p2.x - p1.x);
};

// Vector operations for Rake logic
export const vecSub = (v1: {x:number, y:number}, v2: {x:number, y:number}) => ({ x: v1.x - v2.x, y: v1.y - v2.y });
export const vecAdd = (v1: {x:number, y:number}, v2: {x:number, y:number}) => ({ x: v1.x + v2.x, y: v1.y + v2.y });
export const vecMul = (v: {x:number, y:number}, s: number) => ({ x: v.x * s, y: v.y * s });
export const vecNormalize = (v: {x:number, y:number}) => {
  const len = Math.sqrt(v.x * v.x + v.y * v.y);
  return len === 0 ? {x: 0, y: 0} : { x: v.x / len, y: v.y / len };
};
export const vecPerpendicular = (v: {x:number, y:number}) => ({ x: -v.y, y: v.x });
