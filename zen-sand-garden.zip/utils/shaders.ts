
export const VS_BASE = `
  attribute vec2 position;
  varying vec2 vUv;
  void main() {
    vUv = position * 0.5 + 0.5;
    gl_Position = vec4(position, 0.0, 1.0);
  }
`;

// PHYSICS SHADER: RAKE SIMULATION
export const FS_SIMULATION = `
  precision highp float;
  uniform sampler2D uTexture;
  uniform vec2 uMouse; 
  uniform vec2 uPrevMouse;
  uniform float uBrushSize;
  uniform float uBrushPressure;
  uniform float uRakeSpacing;
  uniform float uAspectRatio;
  uniform int uIsDown;

  varying vec2 vUv;

  // Psuedo-random for sand grain displacement
  float rand(vec2 co){
      return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
  }

  void main() {
    vec4 data = texture2D(uTexture, vUv);
    float height = data.r;

    vec2 uv = vUv;
    uv.x *= uAspectRatio;
    
    vec2 mouse = uMouse;
    mouse.x *= uAspectRatio;
    
    vec2 prevMouse = uPrevMouse;
    prevMouse.x *= uAspectRatio;

    // Stroke Calculations
    vec2 strokeDir = mouse - prevMouse;
    float strokeLen = length(strokeDir);
    
    // Distance from segment
    vec2 pa = uv - prevMouse;
    vec2 ba = strokeDir;
    float h = clamp( dot(pa,ba)/dot(ba,ba), 0.0, 1.0 );
    vec2 pOnLine = ba * h;
    float dist = length( pa - pOnLine );

    float radius = uBrushSize;
    
    // Only affect sand if mouse is down and moving (or just clicked)
    if (uIsDown == 1) {
      if (dist < radius) {
        
        // --- RAKE PHYSICS V2 ---
        
        // 1. Calculate Perpendicular Distance for Tines
        vec2 dir = (strokeLen > 0.0001) ? normalize(strokeDir) : vec2(1.0, 0.0);
        vec2 perp = vec2(-dir.y, dir.x);
        float distPerp = dot(uv - mouse, perp);

        // 2. Frequency of Tines
        // We use the inverse of spacing. 
        float spacing = max(uRakeSpacing, 0.001);
        
        // 3. Normalized Tine Coordinate
        float t = distPerp / spacing;
        
        // 4. Triangle Wave Profile (Sharp Peaks)
        // fract(t) creates a sawtooth. abs(fract - 0.5) makes it a triangle.
        // Result is 0.0 (valley) to 1.0 (peak).
        float triWave = 1.0 - 2.0 * abs(fract(t + 0.5) - 0.5);
        
        // 5. Shaping (Flat Valleys, Sharp Peaks)
        // Map 0..1 to -1..1 range
        float profile = triWave * 2.0 - 1.0;
        
        // Clip the bottom to simulate the flat tine clearing the sand
        // This makes the "Furrow" flat and the "Ridge" sharp.
        // Range becomes approx -0.6 to 1.0
        float tineShape = max(profile, -0.6);
        
        // 6. Sand Accumulation Noise (Gritty Ridges)
        // Add noise only to the positive parts (the piles)
        // This makes the collected sand look loose and organic
        float grain = rand(vUv * 50.0 + uBrushPressure) * 0.15;
        if (tineShape > 0.0) {
           tineShape += grain;
           // Exaggerate peaks to simulate piling up
           tineShape *= 1.2; 
        }

        // 7. Brush Edge Falloff
        // Smoothly fade the effect at the edge of the brush radius
        float edge = smoothstep(radius, radius * 0.7, dist);
        
        // 8. Calculate New Height
        // Base is 0.5. TineShape adds/subtracts.
        float targetHeight = 0.5 + (tineShape * 0.5 * uBrushPressure);
        
        // 9. Apply to Surface (Plasticity)
        // mix based on falloff. 
        // 0.5 mix factor gives it a bit of "resistance" so it feels like heavy sand
        height = mix(height, targetHeight, edge * 0.5);
      } 
    }
    
    gl_FragColor = vec4(height, data.gba);
  }
`;

// RENDERING SHADER: ARCHITECTURAL ZEN
export const FS_RENDER = `
  precision highp float;
  uniform sampler2D uHeightMap;
  uniform sampler2D uNoiseTexture;
  uniform vec2 uResolution;
  uniform vec3 uColorLight;
  uniform vec3 uColorDark;
  uniform vec3 uColorShadow;
  
  varying vec2 vUv;

  void main() {
    vec2 onePixel = 1.0 / uResolution;
    
    // Sample height for normal map
    float d = 1.5;
    float h = texture2D(uHeightMap, vUv).r;
    float hL = texture2D(uHeightMap, vUv + vec2(-onePixel.x * d, 0.0)).r;
    float hR = texture2D(uHeightMap, vUv + vec2(onePixel.x * d, 0.0)).r;
    float hD = texture2D(uHeightMap, vUv + vec2(0.0, -onePixel.y * d)).r;
    float hU = texture2D(uHeightMap, vUv + vec2(0.0, onePixel.y * d)).r;
    
    // --- MICRO GRAIN TEXTURE ---
    // We add noise to the neighbor samples to simulate granular surface normals
    float grainScale = 4.0;
    float nL = texture2D(uNoiseTexture, (vUv + vec2(-onePixel.x*d, 0.0)) * grainScale).r * 0.02;
    float nR = texture2D(uNoiseTexture, (vUv + vec2(onePixel.x*d, 0.0)) * grainScale).r * 0.02;
    float nD = texture2D(uNoiseTexture, (vUv + vec2(0.0, -onePixel.y*d)) * grainScale).r * 0.02;
    float nU = texture2D(uNoiseTexture, (vUv + vec2(0.0, onePixel.y*d)) * grainScale).r * 0.02;

    // Calculate Normal with grain
    vec3 normal = normalize(vec3((hL + nL) - (hR + nR), (hD + nD) - (hU + nU), 0.035));
    
    // Lighting
    vec3 lightDir = normalize(vec3(-0.4, 0.6, 0.7));
    float diff = max(dot(normal, lightDir), 0.0);
    
    // Shadows (Ambient Occlusion)
    // Darken areas that are deep (h < 0.5) OR have steep slopes
    float ao = smoothstep(0.0, 0.8, h);
    float slope = 1.0 - abs(dot(normal, vec3(0.0,0.0,1.0)));
    ao -= slope * 0.4; 

    // Specular Sparkles
    vec3 viewDir = vec3(0.0, 0.0, 1.0);
    vec3 reflectDir = reflect(-lightDir, normal);
    float specBase = max(dot(viewDir, reflectDir), 0.0);
    float sparkleNoise = texture2D(uNoiseTexture, vUv * 8.0).r;
    // Only sparkle on the 'tops' of grains
    float spec = pow(specBase, 20.0) * step(0.6, sparkleNoise) * 0.8;

    // Coloring
    // Base mix between dark sand and light sand based on height
    vec3 col = mix(uColorDark, uColorLight, smoothstep(0.3, 0.7, h));
    
    // Apply shadows
    col = mix(uColorShadow, col, diff * ao + 0.25);
    
    // Apply sparkles
    col += vec3(0.95, 0.95, 1.0) * spec;

    // Soft Vignette
    float vig = 1.0 - smoothstep(0.3, 1.3, length(vUv - 0.5));
    col *= mix(1.0, 0.85, vig);

    gl_FragColor = vec4(col, 1.0);
  }
`;

// INIT SHADER: CONCENTRIC RIPPLES
export const FS_INIT = `
  precision highp float;
  varying vec2 vUv;
  
  void main() {
    // Center point
    vec2 center = vec2(0.5, 0.5);
    float dist = length(vUv - center);
    
    // Zen Ripple Pattern
    // Base height
    float h = 0.5;
    
    // Create concentric rings
    // Frequency increases slightly further out for perspective effect? 
    // No, keep it steady for zen feel.
    float rings = cos(dist * 150.0);
    
    // Soften rings as they get very far
    float falloff = smoothstep(0.5, 0.0, dist);
    
    h += rings * 0.03 * falloff;

    gl_FragColor = vec4(h, 0.0, 0.0, 1.0);
  }
`;
