
export type Point = {
  x: number;
  y: number;
};

export type BezierCurve = {
  start: Point;
  cp1: Point;
  cp2: Point;
  end: Point;
};

export type Vector2 = {
  x: number;
  y: number;
};

export enum ZenPatternMode {
  FLOW = 'flow',
  CONCENTRIC = 'concentric',
  WAVE = 'wave',
  SPIRAL = 'spiral'
}

export type ZenConfig = {
  pattern: ZenPatternMode;
  isDark: boolean;
  brushSize: number; // 0.0 to 1.0
  brushPressure: number;
  rakeSpacing: number; // Frequency of lines
  resetTrigger: number; // Timestamp/ID to trigger reset
};
