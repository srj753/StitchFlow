
import React, { useState } from 'react';
import { ZenBackground } from './components/ZenBackground';
import { ZenConfig, ZenPatternMode } from './types';
import { RefreshCw } from 'lucide-react';

function App() {
  const [config, setConfig] = useState<ZenConfig>({
    pattern: ZenPatternMode.FLOW,
    isDark: false,
    brushSize: 0.025, // Precision size (approx 5% screen width)
    brushPressure: 0.8,
    rakeSpacing: 0.008, // Approx 6 tines at this size
    resetTrigger: 0
  });

  const [uiVisible, setUiVisible] = useState(true);

  const toggleTheme = () => setConfig(prev => ({ ...prev, isDark: !prev.isDark }));
  const handleReset = () => setConfig(prev => ({ ...prev, resetTrigger: prev.resetTrigger + 1 }));

  return (
    <div className="relative w-full h-screen font-sans selection:bg-neutral-300 selection:text-neutral-900 overflow-hidden">
      
      {/* Background Simulation */}
      <div className="absolute inset-0 z-0">
        <ZenBackground config={config} />
      </div>

      {/* Foreground Header */}
      <div className={`relative z-10 flex flex-col items-center justify-center h-full pointer-events-none transition-opacity duration-700 ${config.isDark ? 'text-white' : 'text-[#8A847A]'}`}>
        <h1 className="text-4xl md:text-6xl font-extralight tracking-[0.3em] mb-4 opacity-90 mix-blend-multiply drop-shadow-sm">
          ZEN
        </h1>
        <p className="text-[10px] md:text-xs uppercase tracking-[0.4em] opacity-70">Interactive Sand Garden</p>
      </div>

      {/* Controls Bar */}
      <div className={`fixed bottom-10 left-1/2 -translate-x-1/2 z-20 transition-all duration-500 ${uiVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
        <div className={`
          flex items-center gap-6 px-8 py-5 rounded-full shadow-2xl backdrop-blur-xl border
          ${config.isDark ? 'bg-neutral-900/60 border-neutral-700 text-neutral-300' : 'bg-[#FFFCEE]/80 border-[#E9DCC4] text-[#6A665E]'}
        `}>
          
          {/* Tool Size */}
          <div className="flex flex-col gap-2 w-28">
             <div className="flex justify-between items-center opacity-60">
                <label className="text-[9px] uppercase font-bold tracking-widest">Rake Size</label>
             </div>
             <input 
               type="range" 
               min="0.005" 
               max="0.05" 
               step="0.001"
               value={config.brushSize}
               onChange={(e) => setConfig(p => ({ ...p, brushSize: parseFloat(e.target.value) }))}
               className="w-full h-[2px] bg-current rounded-full appearance-none cursor-pointer hover:h-[4px] transition-all"
             />
          </div>

          <div className="w-px h-8 bg-current opacity-20"></div>

          {/* Rake Spacing */}
          <div className="flex flex-col gap-2 w-28">
             <div className="flex justify-between items-center opacity-60">
                <label className="text-[9px] uppercase font-bold tracking-widest">Density</label>
             </div>
             <input 
               type="range" 
               min="0.002" 
               max="0.015" 
               step="0.0001"
               value={config.rakeSpacing}
               onChange={(e) => setConfig(p => ({ ...p, rakeSpacing: parseFloat(e.target.value) }))}
               className="w-full h-[2px] bg-current rounded-full appearance-none cursor-pointer hover:h-[4px] transition-all"
             />
          </div>

          <div className="w-px h-8 bg-current opacity-20"></div>

          <div className="flex items-center gap-2">
            {/* Reset Button */}
            <button 
              onClick={handleReset}
              className="p-3 rounded-full hover:bg-black/5 transition-transform active:scale-95 active:rotate-180 duration-500"
              title="Reset Sand"
            >
               <RefreshCw size={18} strokeWidth={1.5} />
            </button>

            {/* Theme Button */}
            <button 
              onClick={toggleTheme}
              className="p-3 rounded-full hover:bg-black/5 transition-transform active:scale-95"
              title="Toggle Theme"
            >
              {config.isDark ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
              ) : (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
