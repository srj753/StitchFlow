
import React, { useRef, useEffect } from 'react';
import { ZenConfig } from '../types';
import { createProgram, createTexture, createNoiseTexture, createFramebuffer, FULLSCREEN_QUAD_VERTS } from '../utils/webgl';
import { VS_BASE, FS_SIMULATION, FS_RENDER, FS_INIT } from '../utils/shaders';

interface ZenBackgroundProps {
  config: ZenConfig;
}

export const ZenBackground: React.FC<ZenBackgroundProps> = ({ config }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Bridge React state to WebGL loop
  const configRef = useRef(config);

  // WebGL State
  const glRef = useRef<WebGLRenderingContext | null>(null);
  const programsRef = useRef<any>(null);
  const framebuffersRef = useRef<any>(null);
  const noiseTexRef = useRef<WebGLTexture | null>(null);
  const textureTypeRef = useRef<number>(0);
  const lastResetRef = useRef<number>(0);
  
  const animationFrameRef = useRef<number>(0);
  
  // Interaction State
  const mouseRef = useRef({ 
    x: 0.5, 
    y: 0.5, 
    isDown: false, 
    lastX: 0.5, 
    lastY: 0.5
  });

  // Keep configRef in sync with props
  useEffect(() => {
    configRef.current = config;
  }, [config]);

  // Initialize WebGL
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const gl = canvas.getContext('webgl', { 
        antialias: false,
        depth: false,
        preserveDrawingBuffer: true,
        alpha: false
    });
    if (!gl) {
        console.error("WebGL not supported");
        return;
    }

    // --- ROBUST TEXTURE TYPE DETECTION ---
    gl.getExtension('OES_texture_float');
    gl.getExtension('OES_texture_float_linear');
    gl.getExtension('WEBGL_color_buffer_float'); 
    
    const extHalfFloat = gl.getExtension('OES_texture_half_float');
    gl.getExtension('OES_texture_half_float_linear');
    gl.getExtension('EXT_color_buffer_half_float'); 

    // Helper to check if a texture type is renderable (avoids Framebuffer Incomplete 36054)
    const getRenderableTextureType = () => {
        const candidates: number[] = [];
        // 1. Try Float (Best Precision)
        candidates.push(gl.FLOAT);
        // 2. Try Half Float (Good Precision, Mobile Friendly)
        if (extHalfFloat) {
            candidates.push(extHalfFloat.HALF_FLOAT_OES);
        }
        // 3. Fallback to Byte (Guaranteed support, Lower Precision)
        candidates.push(gl.UNSIGNED_BYTE);

        for (const type of candidates) {
            const tex = gl.createTexture();
            gl.bindTexture(gl.TEXTURE_2D, tex);
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 2, 2, 0, gl.RGBA, type, null);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

            const fb = gl.createFramebuffer();
            gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
            gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);

            const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
            
            gl.deleteTexture(tex);
            gl.deleteFramebuffer(fb);

            if (status === gl.FRAMEBUFFER_COMPLETE) {
                return type;
            }
        }
        return gl.UNSIGNED_BYTE;
    };

    textureTypeRef.current = getRenderableTextureType();
    glRef.current = gl;

    // Compile Shaders
    const simProg = createProgram(gl, VS_BASE, FS_SIMULATION);
    const renderProg = createProgram(gl, VS_BASE, FS_RENDER);
    const initProg = createProgram(gl, VS_BASE, FS_INIT);

    if (!simProg || !renderProg || !initProg) return;
    programsRef.current = { sim: simProg, render: renderProg, init: initProg };

    // Create Noise Texture for Grain
    const noiseSize = 512;
    const noiseData = new Float32Array(noiseSize * noiseSize * 4);
    for(let i=0; i<noiseData.length; i++) {
      noiseData[i] = Math.random();
    }
    const noiseTex = createNoiseTexture(gl, noiseSize, noiseSize, noiseData);
    if(noiseTex) noiseTexRef.current = noiseTex;

    handleResize();
    window.addEventListener('resize', handleResize);
    loop();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameRef.current);
    };
  }, []);

  const resetSimulation = (gl: WebGLRenderingContext) => {
    if (!framebuffersRef.current || !programsRef.current) return;

    const { fb: fbA } = framebuffersRef.current.read;
    const { fb: fbB } = framebuffersRef.current.write;

    gl.useProgram(programsRef.current.init);
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbA);
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
    
    // Draw Init Pattern
    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, FULLSCREEN_QUAD_VERTS, gl.STATIC_DRAW);
    
    const posLoc = gl.getAttribLocation(programsRef.current.init, 'position');
    gl.enableVertexAttribArray(posLoc);
    gl.vertexAttribPointer(posLoc, 2, gl.FLOAT, false, 0, 0);

    gl.drawArrays(gl.TRIANGLES, 0, 6);
    
    // Copy to B to ensure consistency
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbB);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  };

  const handleResize = () => {
    if (!containerRef.current || !glRef.current) return;
    const gl = glRef.current;
    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 2); 

    canvasRef.current!.width = width * dpr;
    canvasRef.current!.height = height * dpr;

    gl.viewport(0, 0, width * dpr, height * dpr);

    // Re-create Buffers
    const texType = textureTypeRef.current;
    
    // Physics Buffers
    const texA = createTexture(gl, width * dpr, height * dpr, null, texType, gl.NEAREST);
    const fbA = texA ? createFramebuffer(gl, texA) : null;
    
    const texB = createTexture(gl, width * dpr, height * dpr, null, texType, gl.NEAREST);
    const fbB = texB ? createFramebuffer(gl, texB) : null;

    if (fbA && fbB) {
      framebuffersRef.current = {
        read: { fb: fbA, tex: texA },
        write: { fb: fbB, tex: texB }
      };
      // Initial Reset
      resetSimulation(gl);
    }
  };

  const loop = () => {
    const gl = glRef.current;
    if (gl && programsRef.current && framebuffersRef.current) {
      const cfg = configRef.current; // Use Ref to get latest state

      // Check for Reset Signal
      if (cfg.resetTrigger !== lastResetRef.current) {
        resetSimulation(gl);
        lastResetRef.current = cfg.resetTrigger;
      }

      // 1. SIMULATION STEP
      gl.useProgram(programsRef.current.sim);
      gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffersRef.current.write.fb);
      
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, framebuffersRef.current.read.tex);
      gl.uniform1i(gl.getUniformLocation(programsRef.current.sim, 'uTexture'), 0);

      // Mouse State
      gl.uniform2f(gl.getUniformLocation(programsRef.current.sim, 'uMouse'), mouseRef.current.x, 1.0 - mouseRef.current.y);
      gl.uniform2f(gl.getUniformLocation(programsRef.current.sim, 'uPrevMouse'), mouseRef.current.lastX, 1.0 - mouseRef.current.lastY);
      gl.uniform1i(gl.getUniformLocation(programsRef.current.sim, 'uIsDown'), mouseRef.current.isDown ? 1 : 0);
      
      // Config - Read from REF
      gl.uniform1f(gl.getUniformLocation(programsRef.current.sim, 'uBrushSize'), cfg.brushSize);
      gl.uniform1f(gl.getUniformLocation(programsRef.current.sim, 'uBrushPressure'), cfg.brushPressure);
      gl.uniform1f(gl.getUniformLocation(programsRef.current.sim, 'uRakeSpacing'), cfg.rakeSpacing);
      gl.uniform1f(gl.getUniformLocation(programsRef.current.sim, 'uAspectRatio'), gl.canvas.width / gl.canvas.height);

      // Draw Sim Quad
      const buffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, FULLSCREEN_QUAD_VERTS, gl.STATIC_DRAW);
      const posLoc = gl.getAttribLocation(programsRef.current.sim, 'position');
      gl.enableVertexAttribArray(posLoc);
      gl.vertexAttribPointer(posLoc, 2, gl.FLOAT, false, 0, 0);
      gl.drawArrays(gl.TRIANGLES, 0, 6);

      // 2. RENDER STEP
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.useProgram(programsRef.current.render);
      
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, framebuffersRef.current.write.tex);
      gl.uniform1i(gl.getUniformLocation(programsRef.current.render, 'uHeightMap'), 0);
      
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, noiseTexRef.current);
      gl.uniform1i(gl.getUniformLocation(programsRef.current.render, 'uNoiseTexture'), 1);

      gl.uniform2f(gl.getUniformLocation(programsRef.current.render, 'uResolution'), gl.canvas.width, gl.canvas.height);
      
      // COLOR THEME
      if (cfg.isDark) {
          // Dark Basalt
          gl.uniform3f(gl.getUniformLocation(programsRef.current.render, 'uColorLight'), 0.35, 0.35, 0.38);
          gl.uniform3f(gl.getUniformLocation(programsRef.current.render, 'uColorDark'), 0.15, 0.15, 0.18);
          gl.uniform3f(gl.getUniformLocation(programsRef.current.render, 'uColorShadow'), 0.0, 0.0, 0.02);
      } else {
          // REQUESTED CREAM PALETTE
          // #FFFCEE -> vec3(1.0, 0.99, 0.93)
          gl.uniform3f(gl.getUniformLocation(programsRef.current.render, 'uColorLight'), 1.0, 0.988, 0.933); 
          // #E9DCC4 -> vec3(0.91, 0.86, 0.77)
          gl.uniform3f(gl.getUniformLocation(programsRef.current.render, 'uColorDark'), 0.913, 0.862, 0.768);
          // Soft Beige Shadow (Lightened from previous version)
          // Approx #B8B0A0 -> 0.72, 0.69, 0.62
          gl.uniform3f(gl.getUniformLocation(programsRef.current.render, 'uColorShadow'), 0.72, 0.69, 0.62);
      }

      gl.drawArrays(gl.TRIANGLES, 0, 6);

      // Swap
      const temp = framebuffersRef.current.read;
      framebuffersRef.current.read = framebuffersRef.current.write;
      framebuffersRef.current.write = temp;
    }

    // Update Mouse
    mouseRef.current.lastX = mouseRef.current.x;
    mouseRef.current.lastY = mouseRef.current.y;

    animationFrameRef.current = requestAnimationFrame(loop);
  };

  const updateMouse = (e: React.PointerEvent) => {
    if(!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    
    mouseRef.current.x = x;
    mouseRef.current.y = y;
  };

  return (
    <div ref={containerRef} className="relative w-full h-full bg-[#E9DCC4] overflow-hidden cursor-crosshair">
      <canvas 
        ref={canvasRef} 
        className="absolute inset-0 block w-full h-full touch-none"
        onPointerDown={(e) => {
            mouseRef.current.isDown = true;
            (e.target as HTMLElement).setPointerCapture(e.pointerId);
            updateMouse(e);
        }}
        onPointerUp={(e) => {
            mouseRef.current.isDown = false;
            (e.target as HTMLElement).releasePointerCapture(e.pointerId);
        }}
        onPointerMove={updateMouse}
      />
    </div>
  );
};
