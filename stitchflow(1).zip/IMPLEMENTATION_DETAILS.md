
# StitchFlow Architecture & Implementation Guide

This document details the core logic of the StitchFlow application, specifically for integrating the pattern parsing engines (AI & Regex) and handling multimodal inputs.

## 1. Dual-Mode Parsing Architecture

StitchFlow supports two distinct parsing strategies:
1.  **AI Mode (Gemini API):** Handles complex, unstructured data, PDFs, Images, and sloppy text.
2.  **Local Mode (Regex Engine):** Handles clean text copy-pasted from blogs/documents without API costs or latency.

### A. Regex Engine (`services/regexService.ts`)
The "No AI" mode uses a custom State Machine parser rather than simple find/replace.

*   **State Machine:** The parser reads the text line-by-line and switches between 4 modes:
    *   `meta`: Extracting title, author, difficulty, gauge.
    *   `materials`: Parsing list items for yarn and tools.
    *   `abbreviations`: Extracting definitions (e.g., "ch - chain").
    *   `instructions`: The "greedy" mode that captures pattern steps.
*   **Key Regex Patterns:**
    *   `rowStartRegex`: Matches "Row 1", "Round 1", "R1", "Next Row", and numbered lists "1.".
    *   `stitchCountRegex`: Extracts "(12 sts)" or "[24]" at the end of lines.
    *   `sectionHeaders`: Heuristic detection of "**Header**", "Header:", or ALL CAPS lines.
*   **Integration:**
    *   Call `parsePatternRegex(textString)` -> Returns `Pattern` object immediately.

### B. Gemini AI Service (`services/geminiService.ts`)
The AI mode leverages Google's Gemini Flash 2.5 for multimodal understanding.

*   **Multimodal Input:**
    *   Accepts `text` (string) AND/OR `files` (Array of Base64 data).
    *   Files are mapped to `inlineData` parts in the API payload.
    *   Supports `image/*` and `application/pdf` MIME types.
*   **System Instructions:**
    *   Defined in `constants.ts`.
    *   Enforces a strict JSON schema output.
    *   Specifically instructed to handle "Romance text" vs "Technical notes".
*   **Integration:**
    *   Call `parsePatternWithGemini(text, filesArray)` -> Returns Promise<Pattern>.

## 2. File Handling & State Management

### Data Structures
*   **`FileData` Interface:**
    ```typescript
    interface FileData {
      mimeType: string; // e.g., 'image/png', 'application/pdf'
      data: string;     // Base64 encoded string (no data: URI prefix)
      name: string;     // Original filename
    }
    ```

### App State (`App.tsx`)
*   `input`: String state for the text area.
*   `files`: Array state `FileData[]` for uploaded attachments.
*   `state`: Object containing `isLoading`, `error`, and `pattern` (the result).

### Website Parsing Strategy
Browser security (CORS) prevents client-side apps from fetching external URLs (e.g., `fetch('https://ravelry.com/...')`).
*   **Solution:** We instruct the user to "Select All" + "Copy" on the target website and paste into the text area.
*   **Alternative:** User can "Print to PDF" on the website and upload the PDF file.
*   **Implementation:** The UI in `PatternInput.tsx` has been updated with a specific hint: *"For websites: Press Ctrl+A on the site, Copy, then Paste below"*.

## 3. Extending the Parser

To add new features (e.g., Chart support):
1.  **Update `types.ts`:** Add a `charts` field to the `Pattern` interface.
2.  **Update `constants.ts`:** Add the `charts` field to the `SYSTEM_INSTRUCTION` JSON schema.
3.  **Update `PatternViewer.tsx`:** Add a component to render the chart data.
