
import React, { useState, useRef } from 'react';
import { EXAMPLE_INPUT } from '../constants';
import { Sparkles, FileText, Image, FileUp, X, PlayCircle, Globe } from 'lucide-react';
import { FileData } from '../types';

interface PatternInputProps {
  input: string;
  setInput: (value: string) => void;
  files: FileData[];
  setFiles: (files: FileData[]) => void;
  onGenerate: () => void;
  onLocalParse: () => void;
  isLoading: boolean;
}

export const PatternInput: React.FC<PatternInputProps> = ({ 
  input, 
  setInput,
  files,
  setFiles,
  onGenerate, 
  onLocalParse,
  isLoading 
}) => {
  const [activeTab, setActiveTab] = useState<'text' | 'file'>('text');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = e.target.files;
    if (!selectedFiles) return;

    const newFiles: FileData[] = [];
    
    for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        if (file.size > 20 * 1024 * 1024) {
            alert(`File ${file.name} is too large. Max 20MB.`);
            continue;
        }

        const promise = new Promise<FileData>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const result = reader.result as string;
                resolve({
                    mimeType: file.type,
                    data: result.split(',')[1],
                    name: file.name
                });
            };
            reader.readAsDataURL(file);
        });

        const fileData = await promise;
        newFiles.push(fileData);
    }

    setFiles([...files, ...newFiles]);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeFile = (index: number) => {
    const newFiles = [...files];
    newFiles.splice(index, 1);
    setFiles(newFiles);
  };

  return (
    <div className="max-w-3xl mx-auto">
       <div className="text-center mb-10">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-stone-800 mb-4 tracking-tight">
            StitchFlow
          </h1>
          <p className="text-lg text-stone-500 max-w-lg mx-auto">
            Transform text, websites, PDFs, or images into interactive knitting & crochet patterns.
          </p>
       </div>

      <div className="bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden">
        {/* Tabs */}
        <div className="flex border-b border-stone-100">
          <button 
            className={`flex-1 py-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${activeTab === 'text' ? 'bg-white text-rose-600 border-b-2 border-rose-500' : 'bg-stone-50 text-stone-500 hover:text-stone-800'}`}
            onClick={() => setActiveTab('text')}
          >
            <div className="flex gap-2">
                <FileText size={18} />
                <span className="opacity-30">|</span>
                <Globe size={18} />
            </div>
            Text / Website
          </button>
          <button 
             className={`flex-1 py-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${activeTab === 'file' ? 'bg-white text-rose-600 border-b-2 border-rose-500' : 'bg-stone-50 text-stone-500 hover:text-stone-800'}`}
             onClick={() => setActiveTab('file')}
          >
            <div className="flex gap-2">
                <FileUp size={18} />
                <span className="opacity-30">|</span>
                <Image size={18} />
            </div>
            PDF / Images
          </button>
        </div>

        <div className="p-6 md:p-8 space-y-6">
          
          {activeTab === 'text' ? (
            <div className="relative animate-in fade-in duration-300">
               <label htmlFor="pattern-text" className="block text-sm font-semibold text-stone-700 mb-2 uppercase tracking-wide flex justify-between">
                 <span>Input Content</span>
                 <span className="text-xs text-rose-500 normal-case font-normal bg-rose-50 px-2 py-0.5 rounded-full">
                    For websites: Press Ctrl+A on the site, Copy, then Paste below
                 </span>
               </label>
               <textarea
                id="pattern-text"
                className="w-full h-64 p-4 rounded-xl border border-stone-300 focus:border-rose-400 focus:ring-4 focus:ring-rose-50 text-stone-700 font-mono text-sm leading-relaxed resize-none transition-all"
                placeholder="Paste the pattern text here..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
              />
              {input.length === 0 && (
                <button 
                  onClick={() => setInput(EXAMPLE_INPUT)}
                  className="absolute bottom-4 right-4 text-xs bg-stone-100 hover:bg-stone-200 text-stone-600 px-3 py-1.5 rounded-lg transition-colors"
                >
                  Paste Example
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-4 animate-in fade-in duration-300">
                <div className="h-48 border-2 border-dashed border-stone-300 rounded-xl flex flex-col items-center justify-center bg-stone-50 relative hover:bg-stone-100 transition-colors">
                     <div className="mb-2 text-stone-400">
                       <Image size={40} className="mx-auto" />
                     </div>
                     <p className="text-stone-600 font-medium mb-1">Click to upload or drag & drop</p>
                     <p className="text-stone-400 text-xs">PDF, PNG, JPG (Max 20MB per file)</p>
                     <input 
                      type="file" 
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      multiple
                      accept="image/*,.pdf"
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                     />
                </div>

                {files.length > 0 && (
                    <div className="space-y-2">
                        <p className="text-xs font-bold text-stone-500 uppercase">Attached Files ({files.length})</p>
                        <div className="grid gap-2 max-h-40 overflow-y-auto">
                            {files.map((f, i) => (
                                <div key={i} className="flex items-center justify-between p-3 bg-white border border-stone-200 rounded-lg shadow-sm">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 bg-rose-100 text-rose-500 rounded flex items-center justify-center shrink-0">
                                            {f.mimeType.includes('pdf') ? <FileText size={16} /> : <Image size={16} />}
                                        </div>
                                        <div className="min-w-0">
                                            <p className="text-sm font-medium text-stone-800 truncate max-w-[200px]">{f.name}</p>
                                            <p className="text-xs text-stone-400 uppercase">{f.mimeType.split('/')[1]}</p>
                                        </div>
                                    </div>
                                    <button 
                                        onClick={() => removeFile(i)}
                                        className="text-stone-400 hover:text-red-500 p-1 rounded-full hover:bg-stone-50"
                                    >
                                        <X size={16} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-4 pt-2">
            <button
              onClick={onGenerate}
              disabled={isLoading || (!input.trim() && files.length === 0)}
              className={`flex-1 py-3.5 px-6 rounded-xl flex items-center justify-center gap-2 font-semibold text-white shadow-lg shadow-rose-200 transition-all transform active:scale-95 ${
                isLoading || (!input.trim() && files.length === 0)
                  ? 'bg-stone-300 cursor-not-allowed shadow-none' 
                  : 'bg-rose-500 hover:bg-rose-600 hover:shadow-rose-300'
              }`}
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Unravelling...</span>
                </>
              ) : (
                <>
                  <Sparkles size={20} />
                  <span>Generate with AI</span>
                </>
              )}
            </button>

            <button
              onClick={onLocalParse}
              disabled={isLoading || !input.trim()}
              className={`flex-1 py-3.5 px-6 rounded-xl flex items-center justify-center gap-2 font-semibold border transition-all active:scale-95 ${
                  !input.trim() 
                  ? 'bg-stone-50 text-stone-400 border-stone-200 cursor-not-allowed'
                  : 'bg-stone-100 text-stone-700 border-stone-200 hover:bg-stone-200 hover:border-stone-300'
              }`}
            >
              <PlayCircle size={20} />
              <span>Local Parse (No AI)</span>
            </button>
          </div>
          
          <p className="text-center text-xs text-stone-400">
            AI mode supports Text, PDF & Images. Local Parse only works on Text.
          </p>
        </div>
      </div>
    </div>
  );
};
