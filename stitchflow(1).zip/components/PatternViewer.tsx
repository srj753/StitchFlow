import React, { useState } from 'react';
import { Pattern, PatternInstructionStep } from '../types';
import { 
  Clock, 
  User, 
  Ruler, 
  Scissors, 
  ChevronDown, 
  ChevronUp, 
  CheckCircle, 
  Circle,
  Palette
} from 'lucide-react';

interface PatternViewerProps {
  pattern: Pattern;
  onReset: () => void;
}

const DifficultyBadge = ({ level }: { level: string }) => {
  const colors = {
    beginner: 'bg-green-100 text-green-800 border-green-200',
    intermediate: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    advanced: 'bg-red-100 text-red-800 border-red-200',
  };

  return (
    <span className={`px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide border ${colors[level as keyof typeof colors] || colors.beginner}`}>
      {level}
    </span>
  );
};

const InstructionStep: React.FC<{ step: PatternInstructionStep, index: number }> = ({ step, index }) => {
  const [isCompleted, setIsCompleted] = useState(false);

  return (
    <div 
      className={`relative pl-10 pr-4 py-4 rounded-lg border transition-all duration-200 cursor-pointer group ${
        isCompleted 
          ? 'bg-stone-50 border-stone-200 opacity-60' 
          : 'bg-white border-stone-200 hover:border-rose-300 hover:shadow-sm'
      }`}
      onClick={() => setIsCompleted(!isCompleted)}
    >
      <div className="absolute left-3 top-4 text-stone-400 group-hover:text-rose-400 transition-colors">
        {isCompleted ? <CheckCircle size={20} className="text-green-500" /> : <Circle size={20} />}
      </div>
      
      <div className="flex justify-between items-start gap-4">
        <div className="flex-1">
          <span className="inline-block text-xs font-bold text-stone-500 mb-1 uppercase tracking-wider">
            {step.row_label}
          </span>
          <p className={`text-stone-800 leading-relaxed ${isCompleted ? 'line-through text-stone-400' : ''}`}>
            {step.instruction}
          </p>
        </div>
        
        {step.stitch_count && (
          <div className="shrink-0 text-xs font-mono bg-stone-100 text-stone-600 px-2 py-1 rounded">
            {step.stitch_count}
          </div>
        )}
      </div>
    </div>
  );
};

export const PatternViewer: React.FC<PatternViewerProps> = ({ pattern, onReset }) => {
  const [activeSection, setActiveSection] = useState<number | null>(0);

  const toggleSection = (index: number) => {
    setActiveSection(activeSection === index ? null : index);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-stone-200 p-6 md:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-rose-50 rounded-bl-full -mr-8 -mt-8 opacity-50 pointer-events-none" />
        
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <DifficultyBadge level={pattern.metadata.difficulty} />
                <span className="text-xs text-stone-400 font-mono">
                  EST. {pattern.metadata.estimatedHours} HR
                </span>
              </div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-stone-800 mb-2">
                {pattern.metadata.name}
              </h1>
              <div className="flex items-center gap-2 text-stone-500 text-sm">
                <User size={16} />
                <span>by {pattern.metadata.designer}</span>
              </div>
            </div>
            
            <button 
              onClick={onReset}
              className="text-sm text-stone-500 hover:text-stone-800 underline underline-offset-4"
            >
              Parse New Pattern
            </button>
          </div>

          <p className="text-stone-600 italic border-l-4 border-rose-200 pl-4 py-1 my-6 bg-stone-50 rounded-r-lg">
            "{pattern.description}"
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
             <div className="bg-stone-50 p-3 rounded-xl border border-stone-100">
                <div className="flex items-center gap-2 text-rose-500 mb-1">
                   <Palette size={16} />
                   <span className="text-xs font-bold uppercase">Yarn</span>
                </div>
                <p className="text-sm font-medium text-stone-700">{pattern.metadata.yarnWeight}</p>
             </div>
             <div className="bg-stone-50 p-3 rounded-xl border border-stone-100">
                <div className="flex items-center gap-2 text-rose-500 mb-1">
                   <Scissors size={16} />
                   <span className="text-xs font-bold uppercase">Hook/Needle</span>
                </div>
                <p className="text-sm font-medium text-stone-700">{pattern.metadata.hookSize}</p>
             </div>
             <div className="bg-stone-50 p-3 rounded-xl border border-stone-100 col-span-2">
                <div className="flex items-center gap-2 text-rose-500 mb-1">
                   <Ruler size={16} />
                   <span className="text-xs font-bold uppercase">Gauge</span>
                </div>
                <p className="text-sm font-medium text-stone-700">{pattern.gauge}</p>
             </div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Sidebar */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-stone-200 p-5 sticky top-6">
            <h3 className="font-serif font-bold text-lg text-stone-800 mb-4 border-b border-stone-100 pb-2">
              Materials
            </h3>
            <ul className="space-y-3 mb-6">
              {pattern.materials.yarn.map((yarn, i) => (
                <li key={i} className="text-sm text-stone-600 flex items-start gap-2">
                  <span className="block w-1.5 h-1.5 mt-1.5 rounded-full bg-rose-400 shrink-0" />
                  {yarn}
                </li>
              ))}
               {pattern.materials.tools.map((tool, i) => (
                <li key={`tool-${i}`} className="text-sm text-stone-600 flex items-start gap-2">
                  <span className="block w-1.5 h-1.5 mt-1.5 rounded-full bg-stone-400 shrink-0" />
                  {tool}
                </li>
              ))}
            </ul>

            <h3 className="font-serif font-bold text-lg text-stone-800 mb-4 border-b border-stone-100 pb-2">
              Abbreviations
            </h3>
            <div className="flex flex-wrap gap-2">
              {pattern.abbreviations.map((abbr, i) => (
                <span key={i} className="text-xs bg-stone-100 text-stone-600 px-2 py-1 rounded border border-stone-200">
                  {abbr}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="md:col-span-2 space-y-6">
          <h2 className="text-2xl font-serif font-bold text-stone-800 flex items-center gap-3">
             Instructions
             <span className="text-sm font-sans font-normal text-stone-400 bg-stone-100 px-2 py-0.5 rounded-full">
               {pattern.instructions.reduce((acc, section) => acc + section.steps.length, 0)} Steps
             </span>
          </h2>

          {pattern.instructions.map((section, sectionIdx) => (
            <div key={sectionIdx} className="bg-white rounded-xl shadow-sm border border-stone-200 overflow-hidden">
              <button 
                onClick={() => toggleSection(sectionIdx)}
                className="w-full flex items-center justify-between p-5 bg-stone-50 hover:bg-stone-100 transition-colors text-left"
              >
                <span className="font-bold text-stone-700 text-lg">{section.section_name}</span>
                {activeSection === sectionIdx ? <ChevronUp className="text-stone-400" /> : <ChevronDown className="text-stone-400" />}
              </button>
              
              {activeSection === sectionIdx && (
                <div className="p-5 space-y-3 border-t border-stone-100">
                  {section.steps.map((step, stepIdx) => (
                    <InstructionStep key={stepIdx} step={step} index={stepIdx} />
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};