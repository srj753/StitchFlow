
export type Difficulty = 'beginner' | 'intermediate' | 'advanced';

export interface PatternMetadata {
  name: string;
  designer: string;
  difficulty: Difficulty;
  yarnWeight: string;
  hookSize: string;
  estimatedHours: number;
}

export interface PatternMaterials {
  yarn: string[];
  tools: string[];
}

export interface PatternInstructionStep {
  row_label: string;
  instruction: string;
  stitch_count: string | null;
}

export interface PatternSection {
  section_name: string;
  steps: PatternInstructionStep[];
}

export interface Pattern {
  metadata: PatternMetadata;
  description: string;
  materials: PatternMaterials;
  gauge: string;
  abbreviations: string[];
  instructions: PatternSection[];
}

export interface GenerationState {
  isLoading: boolean;
  error: string | null;
  pattern: Pattern | null;
}

export interface FileData {
  mimeType: string;
  data: string; // Base64 string without prefix
  name: string;
}
