
import React, { useState } from 'react';
import { PatternInput } from './components/PatternInput';
import { PatternViewer } from './components/PatternViewer';
import { parsePatternWithGemini } from './services/geminiService';
import { parsePatternRegex } from './services/regexService';
import { EXAMPLE_PATTERN } from './constants';
import { Pattern, GenerationState, FileData } from './types';
import { AlertCircle } from 'lucide-react';

const App = () => {
  const [input, setInput] = useState<string>('');
  const [files, setFiles] = useState<FileData[]>([]);
  
  const [state, setState] = useState<GenerationState>({
    isLoading: false,
    error: null,
    pattern: null,
  });

  const handleGenerateAI = async () => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));
    
    try {
      const parsedPattern = await parsePatternWithGemini(input, files);
      setState({ isLoading: false, error: null, pattern: parsedPattern });
    } catch (err: any) {
      setState(prev => ({ 
        ...prev, 
        isLoading: false, 
        error: err.message || "Something went wrong. Check your API key." 
      }));
    }
  };

  const handleLocalParse = async () => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));
    
    // Simulate a short processing time
    setTimeout(() => {
       try {
         let resultPattern: Pattern;

         // If user provided input, try to parse it with regex
         if (input.trim()) {
           resultPattern = parsePatternRegex(input);
         } else {
           // Fallback to example if empty
           resultPattern = EXAMPLE_PATTERN;
         }

         setState({
           isLoading: false,
           error: null,
           pattern: resultPattern
         });
       } catch (err) {
         setState({
           isLoading: false,
           error: "Failed to parse locally. Ensure your text has clear 'Row 1:' or 'Round 1:' labels.",
           pattern: null
         });
       }
    }, 600);
  };

  const handleReset = () => {
    setState({
      isLoading: false,
      error: null,
      pattern: null
    });
    setInput('');
    setFiles([]);
  };

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 pb-20">
      {/* Navbar decoration */}
      <div className="h-2 bg-gradient-to-r from-rose-400 via-rose-300 to-stone-300 w-full" />
      
      <main className="container mx-auto px-4 py-8 md:py-16">
        {state.error && (
          <div className="max-w-3xl mx-auto mb-6 bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3 text-red-700 animate-in fade-in slide-in-from-top-2">
            <AlertCircle className="shrink-0" />
            <p>{state.error}</p>
          </div>
        )}

        {!state.pattern ? (
          <PatternInput 
            input={input}
            setInput={setInput}
            files={files}
            setFiles={setFiles}
            onGenerate={handleGenerateAI}
            onLocalParse={handleLocalParse}
            isLoading={state.isLoading}
          />
        ) : (
          <PatternViewer 
            pattern={state.pattern}
            onReset={handleReset}
          />
        )}
      </main>
      
      {/* Footer */}
      <footer className="text-center text-stone-400 text-sm py-8">
        <p>© {new Date().getFullYear()} StitchFlow. Made with 🧶 and React.</p>
      </footer>
    </div>
  );
};

export default App;
