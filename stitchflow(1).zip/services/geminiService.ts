
import { GoogleGenAI } from "@google/genai";
import { Pattern, FileData } from '../types';
import { SYSTEM_INSTRUCTION } from '../constants';

const apiKey = process.env.API_KEY || '';

export const parsePatternWithGemini = async (text: string, files: FileData[]): Promise<Pattern> => {
  if (!apiKey) {
    throw new Error("API Key is missing. Please use Demo mode or provide a key.");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  // Construct content parts
  const parts: any[] = [];
  
  // Add all files
  if (files && files.length > 0) {
    files.forEach(file => {
      parts.push({
        inlineData: {
          mimeType: file.mimeType,
          data: file.data
        }
      });
    });
  }

  // Add text
  if (text) {
    parts.push({ text: text });
  } else if (files.length > 0) {
    // If only files provided, give a prompt
    parts.push({ text: "Please parse the knitting/crochet pattern in these images/documents." });
  } else {
    throw new Error("No input provided (text or files)");
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        role: 'user',
        parts: parts
      },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: 'application/json',
      }
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error("Empty response from AI");
    }

    return JSON.parse(responseText) as Pattern;

  } catch (error) {
    console.error("Gemini Parse Error:", error);
    throw new Error("Failed to parse pattern. Please try again.");
  }
};
