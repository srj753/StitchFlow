
import { Pattern, PatternSection } from '../types';

export const parsePatternRegex = (text: string): Pattern => {
  // 1. Pre-processing: Split lines and clean up whitespace
  const lines = text.split(/\r?\n/)
    .map(l => l.trim())
    .filter(l => l.length > 0);
  
  const pattern: Pattern = {
    metadata: {
      name: "Untitled Pattern",
      designer: "Unknown",
      difficulty: "intermediate",
      yarnWeight: "Not specified",
      hookSize: "Not specified",
      estimatedHours: 2
    },
    description: "",
    materials: { yarn: [], tools: [] },
    gauge: "Not listed",
    abbreviations: [],
    instructions: []
  };

  let currentSection: PatternSection = { section_name: "Main Pattern", steps: [] };
  
  // State Machine Modes
  type Mode = 'meta' | 'materials' | 'abbreviations' | 'instructions';
  let mode: Mode = 'meta';

  // --- Advanced Regex Definitions ---
  
  // Detects "Materials:", "What you need:", "Supplies"
  const headerMaterials = /^(materials|tools|supplies|you will need|requirements)/i;
  // Detects "Abbreviations:", "Key:", "Stitch Guide"
  const headerAbbr = /^(abbreviations|stitches used|key|legend|special stitches)/i;
  // Detects "Instructions:", "Directions:", "Pattern:", "Start"
  const headerInstructions = /^(instructions|directions|pattern|start|method|body|rounds|rows)/i;

  // Row Starters:
  // 1. "Row 1", "Rnd 1", "R1", "Round 5-10"
  // 2. "Next Row"
  // 3. "1." (Numbered lists common in blogs)
  const rowStartRegex = /^(Row|Round|Rnd|R)\s*(\d+([ -]\d+)?)|^(Next\s*(Row|Round))|^(\d+)\.\s/i;
  
  // Stitch Counts: "(12 sts)", "(24)", "[30 stitches]"
  const stitchCountRegex = /(\(\s*(\d+)\s*(sts|stitches)?\s*\)|\[\s*(\d+)\s*(sts|stitches)?\s*\])$/i;
  
  // Tools: "4mm hook", "US 7 needles"
  const toolRegex = /(hook|needle|marker|scissors|pins)/i;
  const sizeRegex = /\d+(\.\d+)?\s?(mm|cm)/i;

  const finalizeSection = () => {
    if (currentSection.steps.length > 0) {
      pattern.instructions.push({ ...currentSection });
      currentSection = { section_name: "Next Section", steps: [] };
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lowerLine = line.toLowerCase();

    // --- 1. Global Mode Switching ---
    // We check high-level headers to switch context
    if (headerMaterials.test(line)) { mode = 'materials'; continue; }
    if (headerAbbr.test(line)) { mode = 'abbreviations'; continue; }
    
    // Instructions is a 'greedy' mode - once we are in it, it's hard to get out unless we hit a very clear header
    if (headerInstructions.test(line) && mode !== 'instructions') { 
      mode = 'instructions'; 
      continue; 
    }

    // --- 2. Processing per Mode ---

    if (mode === 'meta') {
      // Extract Metadata key: value pairs
      if (line.match(/^(title|pattern name):/i)) {
        pattern.metadata.name = line.replace(/^(title|pattern name):/i, '').trim();
      } else if (line.match(/^(by|designer|author):/i)) {
        pattern.metadata.designer = line.replace(/^(by|designer|author):/i, '').trim();
      } else if (line.match(/difficulty|level|skill/i)) {
        if (lowerLine.includes('easy') || lowerLine.includes('begin')) pattern.metadata.difficulty = 'beginner';
        else if (lowerLine.includes('advanc') || lowerLine.includes('complex')) pattern.metadata.difficulty = 'advanced';
      } else if (line.match(/hook|needle/i)) {
        const match = line.match(sizeRegex);
        if (match) pattern.metadata.hookSize = match[0];
      } else if (line.match(/^gauge:/i)) {
        pattern.gauge = line.replace(/^gauge:/i, '').trim();
      } else if (pattern.metadata.name === "Untitled Pattern" && !line.includes(':') && line.length < 50 && i < 5) {
        // Heuristic: First short line is often the title
        pattern.metadata.name = line.replace(/\*\*/g, '');
      } else if (!line.includes(':')) {
         // Accumulate description
         if (pattern.description.length < 300) {
             pattern.description += line + " ";
         }
      }
    }

    else if (mode === 'materials') {
      const cleanItem = line.replace(/^[-*•]\s*/, '').trim();
      
      if (cleanItem.match(toolRegex) || cleanItem.match(sizeRegex)) {
        pattern.materials.tools.push(cleanItem);
        // Try to grab hook size from tools list if missed in meta
        if (pattern.metadata.hookSize === "Not specified") {
            const match = cleanItem.match(sizeRegex);
            if (match) pattern.metadata.hookSize = match[0];
        }
      } else if (cleanItem.length > 0) {
        pattern.materials.yarn.push(cleanItem);
        // Try to find yarn weight
        const weightMatch = cleanItem.match(/(fingering|sock|sport|dk|worsted|aran|bulky|chunky)/i);
        if (weightMatch) pattern.metadata.yarnWeight = weightMatch[0];
      }
    }

    else if (mode === 'abbreviations') {
      // Common formats: "ch: chain", "ch - chain", "ch = chain", "ch chain"
      // We accept short lines that look like definitions
      if (line.length < 50) {
         pattern.abbreviations.push(line.replace(/[-:=]/, ' - '));
      }
    }

    else if (mode === 'instructions') {
      // --- Instruction Logic ---
      
      // A. Section Detection
      // Look for bold headers like "**Sleeves**" or just "Sleeves:"
      const isSectionHeader = (
        line.match(/^\*\*.*\*\*$/) || 
        (line.endsWith(':') && !rowStartRegex.test(line) && line.length < 30) ||
        (line === line.toUpperCase() && line.length < 20 && !rowStartRegex.test(line)) // ALL CAPS HEADER
      );

      if (isSectionHeader) {
         finalizeSection();
         currentSection.section_name = line.replace(/\*|:/g, '').trim();
         continue;
      }

      // B. Row Detection
      const rowMatch = line.match(rowStartRegex);

      if (rowMatch) {
        // It is a new row
        let label = rowMatch[0];
        // Clean the instruction text: remove the label (e.g. "Row 1:")
        let content = line.substring(label.length).replace(/^[:.)-]\s*/, '').trim();
        
        // Extract Stitch Count
        let stitchCount = null;
        const countMatch = content.match(stitchCountRegex);
        if (countMatch) {
           stitchCount = countMatch[1].replace(/[()\[\]]/g, ''); // Get inner number
           content = content.replace(countMatch[0], '').trim(); // Remove from text
        }

        currentSection.steps.push({
          row_label: label.replace(/\.$/, '').trim(), // Remove trailing dot from "1."
          instruction: content,
          stitch_count: stitchCount ? `${stitchCount} sts` : null
        });
      } else {
        // C. Continuation or Note
        // If it's not a row, but we are in instructions, it might be the second line of a long paragraph
        if (currentSection.steps.length > 0) {
          // Append to previous step
          currentSection.steps[currentSection.steps.length - 1].instruction += " " + line;
        } else {
          // It's a note before the first row of a section
          currentSection.steps.push({
             row_label: "Note",
             instruction: line,
             stitch_count: null
          });
        }
      }
    }
  }

  finalizeSection();
  
  // Clean description
  pattern.description = pattern.description.trim();
  if (pattern.description.length > 300) pattern.description = pattern.description.substring(0, 300) + "...";

  return pattern;
};
