import { Pattern } from './types';

export const EXAMPLE_INPUT = `**Sunny Day Coaster**
By Sarah Crafts
Level: Easy
This cheerful coaster brings a bit of sunshine to your coffee table! It works up quickly in cotton yarn.
Materials:
- Cotton yarn in Yellow
- 4.0mm hook
Gauge: Not critical.
Abbreviations:
ch - chain
dc - double crochet
Instructions:
Round 1: Magic ring, ch 3, 11 dc in ring. Join. (12 sts)
Round 2: Ch 3, dc in same st, 2 dc in each st around. Join. (24 sts)
Fasten off and weave in ends.`;

export const EXAMPLE_PATTERN: Pattern = {
  metadata: {
    name: "Sunny Day Coaster",
    designer: "Sarah Crafts",
    difficulty: "beginner",
    yarnWeight: "Cotton",
    hookSize: "4.0mm",
    estimatedHours: 0.5
  },
  description: "This cheerful coaster brings a bit of sunshine to your coffee table! It works up quickly in cotton yarn.",
  materials: {
    yarn: ["Cotton yarn in Yellow"],
    tools: ["4.0mm hook"]
  },
  gauge: "Not critical",
  abbreviations: ["ch", "dc"],
  instructions: [
    {
      section_name: "Coaster",
      steps: [
        {
          row_label: "Round 1",
          instruction: "Magic ring, ch 3, 11 dc in ring. Join.",
          stitch_count: "12 sts"
        },
        {
          row_label: "Round 2",
          instruction: "Ch 3, dc in same st, 2 dc in each st around. Join.",
          stitch_count: "24 sts"
        },
        {
          row_label: "Finish",
          instruction: "Fasten off and weave in ends.",
          stitch_count: null
        }
      ]
    }
  ]
};

export const SYSTEM_INSTRUCTION = `
**Role:** You are an expert Technical Editor for Knitting and Crochet patterns. Your goal is to parse unstructured pattern data (text, images, or PDFs) into a clean, standardized JSON structure for an app called StitchFlow.
**Objective:** Analyze the input and extract specific data points. You must be precise, especially with abbreviations and row counts.
**Extraction Rules:**
1.  **Description:** Extract the "romance text" or introduction. This is usually at the very top and describes the look, feel, or inspiration of the item. Do NOT include technical notes here.
2.  **Difficulty:** Classify strictly as one of: "beginner", "intermediate", "advanced".
    -   *Beginner:* Basic stitches (sc, dc, knit, purl), simple shaping.
    -   *Intermediate:* Colorwork, cables, lace, complex shaping.
    -   *Advanced:* Micro-crochet, complex garments, advanced lace/brioche.
3.  **Materials & Tools:**
    -   yarnWeight: Standardize to: Lace, Fingering, Sport, DK, Worsted, Bulky, Super Bulky.
    -   hookSize: Format as "X.Xmm" (e.g., "4.0mm" or "5.5mm").
    -   palette: Extract specific color names if listed.
4.  **Stitches:** Extract a list of abbreviations used (e.g., "sc", "k2tog", "tr").
5.  **Instructions (Crucial):**
    -   Break down the pattern into logical **Sections** (e.g., "Sleeve", "Body", "Neckline").
    -   Inside each section, parse **Rows/Rounds**.
    -   If a row is written as "Row 1-5:", expand this if possible, or keep it as a single instruction block with row_count: 5.
    -   Clean up the text: Remove "End of row" counts from the instruction text and put them in the stitch_count field if possible.
**Output Format (Strict JSON):**
{
  "metadata": {
    "name": "String",
    "designer": "String",
    "difficulty": "beginner | intermediate | advanced",
    "yarnWeight": "String",
    "hookSize": "String",
    "estimatedHours": Number
  },
  "description": "String",
  "materials": {
    "yarn": ["String"],
    "tools": ["String"]
  },
  "gauge": "String",
  "abbreviations": ["String"],
  "instructions": [
    {
      "section_name": "String",
      "steps": [
        {
          "row_label": "String",
          "instruction": "String",
          "stitch_count": "String or null"
        }
      ]
    }
  ]
}
Response: Only return the valid JSON object. Do not include markdown formatting like at the start.
`;
