# StitchFlow Refactor Master Blueprint

## Context
The goal is to transform the existing `srj753/StitchFlow` React Native repo into a "Modern, Clean, Apple-esque" crochet companion app. This blueprint defines the **Exact Architecture**, **Routing**, and **UI System** required.

**Core Philosophy:** "The Command Center". The app is not just lists; it's a deep workstation for creators.

## 1. Design System (NativeWind + Reanimated)

### Aesthetics
- **Vibe:** Soft, Calm, Premium. No "grandma" textures.
- **Background:** `bg-stone-50` (#fafaf9).
- **Primary:** `text-violet-800` (#5b21b6).
- **Secondary:** `bg-violet-400` (#a78bfa).
- **Shapes:** `rounded-3xl` for cards, `rounded-full` for buttons.
- **Shadows:** Soft diffuse shadows (`shadow-stone-200`).

### Interactive Physics
- **Buttons:** `active:scale-95` (Tactile feedback).
- **Transitions:** Screens slide up from bottom for deep actions (Project Detail), fade in for tabs.

---

## 2. Directory Structure (Expo Router)

Refactor `/app` to strictly follow this deep-linking structure:

```text
/app
  _layout.tsx             <-- Stack Provider
  
  (tabs)/
    _layout.tsx           <-- Custom Floating Tab Bar
    index.tsx             <-- Home Dashboard
    projects.tsx          <-- Projects List
    patterns.tsx          <-- Pattern Hub
    community.tsx         <-- Inspiration/Testers
    settings.tsx          <-- Settings
  
  /project/
    [id]/
      index.tsx           <-- THE COMMAND CENTER (Counters, Timer, Tabs)
      diagram.tsx         <-- Diagram Editor (Canvas)
    create.tsx            <-- New Project Wizard
  
  /pattern/
    [id].tsx              <-- Viewer (Smart Text / PDF)
    maker.tsx             <-- Pattern Builder Tool
    import.tsx            <-- Import Flow
    library.tsx           <-- Stitch Library Reference
  
  /stash/
    [id].tsx              <-- Yarn Detail + Estimator
    create.tsx            <-- Add Yarn Form
  
  /profile/
    index.tsx             <-- Moodboards & Stats
```

---

## 3. Feature Specifications (Phase 1 Refactor)

### A. Project Detail ("The Command Center")
*DO NOT* make this a simple scroll view. It must have internal tabs:
1.  **Track:** Multi-counters (with Timer toggle), Hook size selector, Yarn list.
2.  **Pattern:** Split view toggle (Parsed Text vs Webview).
3.  **Vision:** Timeline/Moodboard for notes & photos.
4.  **Assistant:** AI Chat interface.

### B. Diagram Editor
A canvas screen using `react-native-skia` or `react-native-svg`.
- **Toolbar:** Pen, Eraser, Layers Toggle.
- **Layers:** Support generic "Layers" array in state.

### C. Community
- **Inspiration Tab:** Masonry List (`@shopify/flash-list`) of images.
- **Testers Tab:** Cards with "Open Call" badges.

### D. Stash Detail
- **Calculator:** A stub UI for "Yarn Estimation" (e.g., Blanket Size -> Skeins needed).

---

## 4. Component Refactor Instructions

1.  **Delete** old React Navigation stacks. Use Expo Router file-based routing.
2.  **Replace** `StyleSheet.create` with `className="..."` (NativeWind).
3.  **Implement** `Header.tsx`: A reusable top bar that handles "Back", "Title", and "Right Action" (e.g., Save, Edit).
4.  **Implement** `CounterCard.tsx`: Must support Haptics (`expo-haptics`) on press.

## 5. Execution Order for Cursor
1.  "Initialize NativeWind and Expo Router structure as per `CURSOR_REFACTOR.md`."
2.  "Build the `ProjectDetail` Command Center with internal tabs."
3.  "Build the `DiagramEditor` skeleton."
4.  "Refactor the Tab Bar to be floating and glassmorphic."
