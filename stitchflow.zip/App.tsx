import React, { useState, useEffect } from 'react';
import { ViewState, Project, ProjectStatus } from './types';
import { Navigation } from './components/Navigation';
import { Home } from './views/Home';
import { Projects } from './views/Projects';
import { ProjectDetail } from './views/ProjectDetail';
import { ProjectCreate } from './views/ProjectCreate';
import { Patterns } from './views/Patterns';
import { PatternDetail } from './views/PatternDetail';
import { PatternImport } from './views/PatternImport';
import { PatternMaker } from './views/PatternMaker';
import { Stash } from './views/Stash';
import { StashDetail } from './views/StashDetail';
import { Community } from './views/Community';
import { Profile } from './views/Profile';
import { DiagramEditor } from './views/DiagramEditor';
import { StitchLibrary } from './views/StitchLibrary';

// Mock Data Initialization
const MOCK_PROJECTS: Project[] = [
  {
    id: '1',
    title: 'Sunny Day Blanket',
    patternName: 'Daisy Granny Square',
    status: ProjectStatus.ACTIVE,
    progress: 35,
    lastUpdated: new Date().toISOString(),
    thumbnailUrl: 'https://picsum.photos/400/400?random=1',
    counters: [
      { id: 'c1', label: 'Row', value: 42, step: 1 },
      { id: 'c2', label: 'Stitch', value: 120, step: 1 }
    ],
    yarnIds: [],
    notes: [
        { id: 'n1', text: 'Remember to switch to hook 4.5mm for the border.', createdAt: new Date().toISOString(), type: 'text' }
    ]
  },
  {
    id: '2',
    title: 'Blue Beanie',
    patternName: 'Ribbed Hat Pattern',
    status: ProjectStatus.PAUSED,
    progress: 80,
    lastUpdated: new Date().toISOString(),
    thumbnailUrl: 'https://picsum.photos/400/400?random=2',
    counters: [
      { id: 'c3', label: 'Row', value: 88, step: 1 }
    ],
    yarnIds: [],
    notes: []
  }
];

const App: React.FC = () => {
  // Navigation Stack State
  const [history, setHistory] = useState<ViewState[]>(['HOME']);
  const currentView = history[history.length - 1];

  const [projects, setProjects] = useState<Project[]>(MOCK_PROJECTS);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  // --- Router Logic ---
  const navigate = (view: ViewState) => {
    // Prevent pushing duplicate consecutive views
    if (currentView !== view) {
       setHistory(prev => [...prev, view]);
    }
  };

  const goBack = () => {
    if (history.length > 1) {
      setHistory(prev => prev.slice(0, -1));
    }
  };

  const handleTabChange = (view: ViewState) => {
    // Tabs reset the stack for that tab context
    setHistory([view]);
  };

  // --- Handlers ---
  const handleSelectProject = (project: Project) => {
    setSelectedProject(project);
    navigate('PROJECT_DETAIL');
  };

  const handleUpdateProject = (updatedProject: Project) => {
    setProjects(prev => prev.map(p => p.id === updatedProject.id ? updatedProject : p));
    setSelectedProject(updatedProject); 
  };

  const renderView = () => {
    switch (currentView) {
      case 'HOME':
        return <Home projects={projects} onSelectProject={handleSelectProject} onOpenProfile={() => navigate('PROFILE')} />;
      
      case 'PROJECTS_LIST':
        return <Projects projects={projects} onSelectProject={handleSelectProject} onCreateProject={() => navigate('PROJECT_CREATE')} />;
      
      case 'PROJECT_CREATE':
        return <ProjectCreate onBack={goBack} />;
      
      case 'PROJECT_DETAIL':
        if (!selectedProject) return null; // Should ideally redirect
        return (
          <ProjectDetail 
            project={selectedProject} 
            onBack={goBack} 
            onUpdateProject={handleUpdateProject}
            onOpenDiagram={() => navigate('DIAGRAM_EDITOR')}
          />
        );

      case 'PATTERNS_LIST':
        return (
            <Patterns 
                onSelectPattern={() => navigate('PATTERN_DETAIL')} 
                onImport={() => navigate('PATTERN_IMPORT')} 
                onMaker={() => navigate('PATTERN_MAKER')}
                onStitchLibrary={() => navigate('STITCH_LIBRARY')}
            />
        );
      
      case 'PATTERN_DETAIL':
        return <PatternDetail onBack={goBack} />;
      
      case 'PATTERN_IMPORT':
        return <PatternImport onBack={goBack} />;

      case 'PATTERN_MAKER':
        return <PatternMaker onBack={goBack} />;

      case 'STITCH_LIBRARY':
        return <StitchLibrary onBack={goBack} />;

      case 'DIAGRAM_EDITOR':
        return <DiagramEditor onBack={goBack} />;

      case 'STASH_LIST':
        return <Stash onAdd={() => navigate('STASH_CREATE')} onDetail={() => navigate('STASH_DETAIL')} />;
      
      case 'STASH_CREATE':
        return (
            <div className="min-h-screen bg-background pt-20 text-center px-10 animate-slide-up">
                <button onClick={goBack} className="mb-4 text-primary">Back</button>
                <h2 className="text-xl font-bold text-text mb-2">Add Yarn</h2>
                <p className="text-muted text-sm">Create stash item skeleton.</p>
            </div>
         );

      case 'STASH_DETAIL':
         return <StashDetail onBack={goBack} />;

      case 'COMMUNITY':
        return <Community />;

      case 'PROFILE':
        return <Profile onBack={goBack} onSettings={() => navigate('SETTINGS')} />;

      case 'SETTINGS':
        return (
             <div className="pt-20 text-center px-10 animate-slide-up">
                <h2 className="text-xl font-bold text-text mb-2">Settings</h2>
                <div className="space-y-4 mt-8">
                    <button onClick={goBack} className="text-sm text-muted mb-4">Back</button>
                    <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">Theme Preference</div>
                    <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm">Data & Sync</div>
                    <div className="bg-white p-4 rounded-2xl border border-stone-200 text-red-400 shadow-sm">Log Out</div>
                </div>
            </div>
        );
      default:
        return <Home projects={projects} onSelectProject={handleSelectProject} onOpenProfile={() => navigate('PROFILE')} />;
    }
  };

  // Views that should hide the bottom navigation
  const fullScreenViews: ViewState[] = [
    'PROJECT_CREATE', 
    'PROJECT_DETAIL', 
    'PATTERN_DETAIL', 
    'PATTERN_IMPORT', 
    'PATTERN_MAKER', 
    'STITCH_LIBRARY',
    'DIAGRAM_EDITOR',
    'PROFILE', 
    'STASH_CREATE', 
    'STASH_DETAIL',
    'SETTINGS'
  ];
  
  const showNav = !fullScreenViews.includes(currentView);

  return (
    <div className="w-full max-w-md mx-auto bg-background min-h-screen relative shadow-2xl overflow-hidden">
      {renderView()}
      
      {showNav && (
        <Navigation currentView={currentView} setView={handleTabChange} />
      )}
    </div>
  );
};

export default App;
