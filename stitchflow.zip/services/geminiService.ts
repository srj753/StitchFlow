import { GoogleGenAI } from "@google/genai";

// In a real production app, this would be handled securely via a backend proxy.
// For this generated demo, we assume the environment variable is available.
const API_KEY = process.env.API_KEY || ''; 

let aiClient: GoogleGenAI | null = null;

export const initGenAI = () => {
  if (API_KEY && !aiClient) {
    aiClient = new GoogleGenAI({ apiKey: API_KEY });
  }
};

export const generateCrochetAdvice = async (query: string, context?: string): Promise<string> => {
  if (!aiClient) {
    initGenAI();
    if (!aiClient) return "Please configure your API Key to use the StitchFlow Assistant.";
  }

  try {
    const model = aiClient!.models; // Non-null assertion safe due to check above
    
    const systemPrompt = `
      You are StitchFlow AI, an expert crochet assistant. 
      Your tone is friendly, modern, and encouraging (not grandma-style, but warm).
      Keep answers concise and helpful for someone currently working on a project.
      If given context about a pattern, refer to it specifically.
    `;

    const prompt = `
      Context: ${context || 'General crochet question'}
      User Question: ${query}
    `;

    const response = await model.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        maxOutputTokens: 300, // Keep it brief for mobile UI
      }
    });

    return response.text || "I couldn't generate a response right now.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I'm having trouble connecting to the crochet knowledge base.";
  }
};