export enum YarnWeight {
  LACE = 'Lace',
  SUPER_FINE = 'Super Fine',
  FINE = 'Fine',
  LIGHT = 'Light',
  MEDIUM = 'Medium',
  BULKY = 'Bulky',
  SUPER_BULKY = 'Super Bulky',
  JUMBO = 'Jumbo'
}

export enum ProjectStatus {
  ACTIVE = 'Active',
  PAUSED = 'Paused',
  COMPLETED = 'Completed'
}

export interface Counter {
  id: string;
  label: string; // e.g., "Row", "Stitch", "Repeat"
  value: number;
  step: number;
}

export interface Yarn {
  id: string;
  brand: string;
  color: string;
  weight: YarnWeight;
  skeins: number;
  metersRemaining: number;
  colorCode?: string; // Hex code for UI visualization
  lot?: string;
}

export interface Note {
  id: string;
  text: string;
  createdAt: string;
  type: 'text' | 'voice' | 'milestone' | 'photo';
  attachmentUrl?: string;
}

export interface Project {
  id: string;
  title: string;
  patternName: string;
  status: ProjectStatus;
  progress: number; // 0-100
  counters: Counter[];
  yarnIds: string[];
  notes: Note[];
  thumbnailUrl?: string;
  lastUpdated: string;
  hookSize?: string;
  timerSeconds?: number;
  timerRunning?: boolean;
}

export interface Pattern {
  id: string;
  title: string;
  author: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  imageUrl: string;
  format: 'PDF' | 'Web' | 'Native'; 
  tags: string[];
}

export interface Stitch {
  id: string;
  name: string;
  category: string;
  difficulty: string;
  videoUrl?: string;
  thumbnailUrl: string;
}

export interface DiagramLayer {
  id: string;
  name: string;
  visible: boolean;
  type: 'drawing' | 'grid' | 'image';
}

export type ViewState = 
  | 'HOME' 
  | 'PROJECTS_LIST' 
  | 'PROJECT_CREATE'
  | 'PROJECT_DETAIL' 
  | 'PATTERNS_LIST' 
  | 'PATTERN_DETAIL'
  | 'PATTERN_IMPORT'
  | 'PATTERN_MAKER'
  | 'STITCH_LIBRARY'
  | 'DIAGRAM_EDITOR'
  | 'STASH_LIST' 
  | 'STASH_CREATE'
  | 'STASH_DETAIL'
  | 'COMMUNITY'
  | 'PROFILE'
  | 'SETTINGS';
