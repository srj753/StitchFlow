import React, { useState, useEffect } from 'react';
import { Plus, Minus, RotateCcw, Timer } from 'lucide-react';
import { Counter } from '../types';

interface CounterCardProps {
  counter: Counter;
  onUpdate: (id: string, newValue: number) => void;
}

export const CounterCard: React.FC<CounterCardProps> = ({ counter, onUpdate }) => {
  const [animate, setAnimate] = useState(false);
  const [timerActive, setTimerActive] = useState(false);

  const handleIncrement = (amount: number) => {
    setAnimate(true);
    // Simulate Haptic
    if (navigator.vibrate) navigator.vibrate(10); 
    onUpdate(counter.id, counter.value + amount);
    setTimeout(() => setAnimate(false), 200);
  };

  const handleDecrement = () => {
    if (counter.value > 0) {
      if (navigator.vibrate) navigator.vibrate(5);
      onUpdate(counter.id, counter.value - 1);
    }
  };

  return (
    <div className="bg-white rounded-3xl p-5 shadow-sm border border-stone-100 flex flex-col items-center justify-between relative overflow-hidden w-full group">
      {/* Subtle background pattern or gradient */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-secondary to-primary opacity-50"></div>
      
      <div className="flex w-full justify-between items-center mb-4">
        <span className="text-muted text-xs font-bold tracking-wider uppercase">{counter.label}</span>
        <div className="flex gap-2">
            <button 
                onClick={() => setTimerActive(!timerActive)}
                className={`transition-colors ${timerActive ? 'text-secondary animate-pulse' : 'text-stone-300 hover:text-stone-400'}`}
            >
                <Timer size={14} />
            </button>
            <button 
                onClick={() => onUpdate(counter.id, 0)}
                className="text-stone-300 hover:text-red-400 transition-colors"
            >
                <RotateCcw size={14} />
            </button>
        </div>
      </div>

      <div className={`text-6xl font-bold text-text mb-6 transition-transform duration-200 ${animate ? 'scale-110' : 'scale-100'}`}>
        {counter.value}
      </div>

      <div className="flex items-center space-x-4 w-full">
        <button 
          onClick={handleDecrement}
          className="flex-1 h-14 rounded-2xl bg-stone-100 text-stone-500 flex items-center justify-center active:bg-stone-200 transition-colors"
        >
          <Minus size={24} />
        </button>
        
        <button 
          onClick={() => handleIncrement(1)}
          className="flex-[2] h-14 rounded-2xl bg-primary text-white flex items-center justify-center shadow-lg shadow-violet-200 active:scale-95 transition-transform"
        >
          <Plus size={32} strokeWidth={3} />
        </button>
      </div>
      
      <div className="flex space-x-2 mt-3 w-full">
         <button 
            onClick={() => handleIncrement(5)}
            className="flex-1 py-2 bg-stone-50 text-xs font-semibold text-muted rounded-xl border border-stone-100 active:bg-stone-100"
         >
            +5
         </button>
         <button 
            onClick={() => handleIncrement(10)}
            className="flex-1 py-2 bg-stone-50 text-xs font-semibold text-muted rounded-xl border border-stone-100 active:bg-stone-100"
         >
            +10
         </button>
      </div>
    </div>
  );
};
