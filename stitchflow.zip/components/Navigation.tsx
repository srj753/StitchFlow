import React from 'react';
import { Home, FolderHeart, Library, Users, Package } from 'lucide-react';
import { ViewState } from '../types';

interface NavigationProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentView, setView }) => {
  
  const getTabClass = (baseView: string, subViews: string[] = []) => {
    const isActive = 
      currentView === baseView || 
      subViews.includes(currentView);

    return `flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors duration-200 ${
      isActive ? 'text-primary' : 'text-stone-400 hover:text-stone-600'
    }`;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 h-20 bg-surface/95 backdrop-blur-xl border-t border-stone-200 pb-5 pt-3 px-2 z-50 shadow-[0_-5px_20px_rgba(0,0,0,0.03)]">
      <div className="flex justify-between items-center h-full max-w-md mx-auto px-4">
        
        <button onClick={() => setView('HOME')} className={getTabClass('HOME')}>
          <Home size={24} strokeWidth={currentView === 'HOME' ? 2.5 : 2} />
          <span className="text-[10px] font-medium mt-1">Home</span>
        </button>
        
        <button onClick={() => setView('PROJECTS_LIST')} className={getTabClass('PROJECTS_LIST', ['PROJECT_DETAIL', 'PROJECT_CREATE', 'DIAGRAM_EDITOR'])}>
          <FolderHeart size={24} strokeWidth={currentView.includes('PROJECT') || currentView === 'DIAGRAM_EDITOR' ? 2.5 : 2} />
          <span className="text-[10px] font-medium mt-1">Projects</span>
        </button>
        
        <button onClick={() => setView('PATTERNS_LIST')} className={getTabClass('PATTERNS_LIST', ['PATTERN_DETAIL', 'PATTERN_IMPORT', 'PATTERN_MAKER', 'STITCH_LIBRARY'])}>
          <Library size={24} strokeWidth={currentView.includes('PATTERN') || currentView === 'STITCH_LIBRARY' ? 2.5 : 2} />
          <span className="text-[10px] font-medium mt-1">Patterns</span>
        </button>

        <button onClick={() => setView('STASH_LIST')} className={getTabClass('STASH_LIST', ['STASH_CREATE', 'STASH_DETAIL'])}>
          <Package size={24} strokeWidth={currentView.includes('STASH') ? 2.5 : 2} />
          <span className="text-[10px] font-medium mt-1">Stash</span>
        </button>

        <button onClick={() => setView('COMMUNITY')} className={getTabClass('COMMUNITY')}>
          <Users size={24} strokeWidth={currentView === 'COMMUNITY' ? 2.5 : 2} />
          <span className="text-[10px] font-medium mt-1">Community</span>
        </button>

      </div>
    </div>
  );
};
