import React from 'react';
import { ArrowLeft, MoreVertical } from 'lucide-react';

interface HeaderProps {
  title: string;
  subtitle?: string;
  onBack: () => void;
  rightAction?: React.ReactNode;
  showMenu?: boolean;
}

export const Header: React.FC<HeaderProps> = ({ title, subtitle, onBack, rightAction, showMenu = false }) => {
  return (
    <div className="sticky top-0 bg-background/90 backdrop-blur-md z-40 px-6 pt-12 pb-4 flex justify-between items-center border-b border-stone-100/50">
      <button 
        onClick={onBack} 
        className="p-2 -ml-2 text-text hover:bg-stone-100 rounded-full active:scale-95 transition-transform"
      >
        <ArrowLeft size={24} />
      </button>
      
      <div className="flex-1 text-center px-4">
        <h1 className="text-lg font-bold text-text truncate">{title}</h1>
        {subtitle && <p className="text-xs text-muted truncate">{subtitle}</p>}
      </div>

      <div className="flex items-center -mr-2 gap-2">
        {rightAction}
        {showMenu && (
            <button className="p-2 text-text hover:bg-stone-100 rounded-full active:scale-95 transition-transform">
            <MoreVertical size={24} />
            </button>
        )}
        {!rightAction && !showMenu && <div className="w-10" />} {/* Spacer to balance title */}
      </div>
    </div>
  );
};
