# StitchFlow Master Blueprint

## 1. Vision & Core Philosophy
**"The Ultimate Crochet Command Center."**

StitchFlow is not just a counter; it is a workflow OS for fiber artists. It replaces Ravelry, Notes App, Goodnotes, and physical tally counters.

**Design Pillars:**
1.  **Aesthetic:** Clean, Soft, Modern (Stone-50 background, Violet-800 Primary). "Apple Design Award" vibe.
2.  **Flow:** Deep Work Features (Counting/Reading) must coexist without context switching.
3.  **Intelligence:** The app helps you read patterns, calculate yarn, and track time.

---

## 2. Directory Structure (Expo Router Compatible)

The `src/app` directory (or just `/app` in Expo Router) is the source of truth for navigation.

```text
/app
  _layout.tsx             <-- Root Stack (Providers, Fonts)
  
  (tabs)/                 <-- Bottom Tab Navigator
    _layout.tsx           <-- Custom Floating Tab Bar
    index.tsx             <-- Home Dashboard
    projects.tsx          <-- Projects List
    patterns.tsx          <-- Pattern Hub
    stash.tsx             <-- Yarn Inventory
    community.tsx         <-- Inspiration Board
  
  /project/
    [id]/
      index.tsx           <-- THE COMMAND CENTER (See Section 3A)
      diagram.tsx         <-- Diagram Editor
    create.tsx            <-- New Project Wizard
  
  /pattern/
    [id].tsx              <-- Standalone Viewer
    maker.tsx             <-- Pattern Builder
    import.tsx            <-- Import Flow
    library.tsx           <-- Stitch Library
  
  /stash/
    [id].tsx              <-- Yarn Detail + Estimator
    create.tsx            <-- Add Yarn Form
  
  /profile/
    index.tsx             <-- User Profile
    settings.tsx          <-- App Settings
```

---

## 3. Deep Feature Specifications

### A. Project Detail ("The Command Center")
This is the most complex screen. It uses **Internal State Tabs** (not router tabs) to manage the workspace.
*   **Track Tab:** Multi-counters, Timer (Stopwatch), Hook Size, Yarn Used.
*   **Pattern Tab:** 
    *   **Split View:** Toggle between "Smart Text" (Parsed) and "Webview" (Original PDF).
    *   **HUD:** A floating overlay with the primary Row Counter so users can read & count simultaneously.
*   **Studio Tab (Vision):** A canvas/masonry layout.
    *   Add Color Swatches (Hex codes).
    *   Add Sketches/Photos.
    *   Add Sticky Notes/Voice Memos.
*   **AI Assistant:** Context-aware chat (knows the current pattern).

### B. Diagram Editor
A vector-based canvas tool.
*   **Features:** Pen, Eraser, Grid Toggle.
*   **Layers:** Background Image (Pattern screenshot) + Drawing Layer (Annotations).

### C. Stash & Calculators
*   **Inventory:** Brand, Color, Weight, Skein Count, Meters Remaining.
*   **Estimator:** "I want to make a [Baby Blanket] using [Worsted] yarn." -> Output: "You need ~1200m".

### D. Community
*   **Inspiration:** Pinterest-style masonry grid.
*   **Testers Board:** Professional job board style for pattern testing calls.

---

## 4. UI/UX Guidelines (NativeWind)

### Color Palette
*   **Background:** `bg-stone-50` (#fafaf9)
*   **Surface:** `bg-white`
*   **Primary:** `text-violet-800` (#5b21b6)
*   **Secondary:** `bg-violet-400` (#a78bfa)
*   **Text:** `text-stone-900`
*   **Muted:** `text-stone-500`

### Components
*   **Cards:** `rounded-3xl border border-stone-100 shadow-sm`.
*   **Buttons:** `rounded-full active:scale-95 transition-transform`.
*   **Headers:** Sticky, blur-effect (`backdrop-blur-md`).

---

## 5. Technical Stack
*   **Framework:** React Native (Expo).
*   **Routing:** Expo Router (File-based).
*   **Styling:** NativeWind (Tailwind CSS).
*   **Icons:** Lucide React Native.
*   **State:** Zustand (for global Stash/User state) + React Query (for Community/Pattern fetching).
*   **Local DB:** WatermelonDB or MMKV for offline-first data.
*   **AI:** Google Gemini SDK (`@google/genai`).

## 6. Implementation Checklist for AI Agents
1.  **Refactor Routing:** Move `Settings` to Profile, Promote `Stash` to Tabs.
2.  **Build Command Center:** Implement the Floating HUD in Project Detail.
3.  **Build Studio:** Implement the Masonry Layout for the Moodboard.
4.  **Polish:** Ensure all touchables have `active:scale` feedback.