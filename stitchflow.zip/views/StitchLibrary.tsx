import React from 'react';
import { Header } from '../components/Header';
import { Search, PlayCircle, Bookmark } from 'lucide-react';

interface StitchLibraryProps {
  onBack: () => void;
}

export const StitchLibrary: React.FC<StitchLibraryProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-background animate-slide-up">
      <Header title="Stitch Library" onBack={onBack} />
      
      <div className="px-6 py-4">
        <div className="bg-white p-3 rounded-2xl border border-stone-200 flex items-center gap-3 shadow-sm mb-6">
            <Search size={18} className="text-stone-400" />
            <input placeholder="Search stitches (e.g. Moss stitch)..." className="flex-1 outline-none text-sm" />
        </div>

        <div className="space-y-6">
            <div>
                <h3 className="text-sm font-bold text-text mb-3">Essentials</h3>
                <div className="space-y-3">
                    {['Single Crochet', 'Double Crochet', 'Magic Ring'].map((stitch, i) => (
                        <div key={i} className="bg-white p-3 rounded-2xl border border-stone-100 flex gap-4 shadow-sm active:scale-[0.99]">
                            <div className="w-16 h-16 bg-stone-100 rounded-xl relative group cursor-pointer">
                                <div className="absolute inset-0 flex items-center justify-center bg-black/10 rounded-xl group-hover:bg-black/20">
                                    <PlayCircle size={20} className="text-white drop-shadow-md" />
                                </div>
                            </div>
                            <div className="flex-1 py-1">
                                <div className="flex justify-between items-start">
                                    <h4 className="font-bold text-sm text-text">{stitch}</h4>
                                    <button className="text-stone-300 hover:text-primary"><Bookmark size={16} /></button>
                                </div>
                                <p className="text-xs text-muted mt-1 line-clamp-2">Basic stitch used in almost every pattern. Perfect for beginners.</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div>
                <h3 className="text-sm font-bold text-text mb-3">Decorative</h3>
                <div className="space-y-3">
                    {['Shell Stitch', 'Popcorn Stitch'].map((stitch, i) => (
                         <div key={i} className="bg-white p-3 rounded-2xl border border-stone-100 flex gap-4 shadow-sm active:scale-[0.99]">
                            <div className="w-16 h-16 bg-stone-100 rounded-xl"></div>
                            <div className="flex-1 py-1">
                                <h4 className="font-bold text-sm text-text">{stitch}</h4>
                                <p className="text-xs text-muted mt-1">Intermediate • Texture</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};
