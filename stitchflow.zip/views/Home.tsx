import React from 'react';
import { Project } from '../types';
import { ArrowRight, Sparkles, Clock } from 'lucide-react';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface HomeProps {
  projects: Project[];
  onSelectProject: (p: Project) => void;
  onOpenProfile: () => void;
}

const data = [
  { name: 'Mon', stitches: 400 },
  { name: 'Tue', stitches: 300 },
  { name: 'Wed', stitches: 200 },
  { name: 'Thu', stitches: 278 },
  { name: 'Fri', stitches: 189 },
  { name: 'Sat', stitches: 600 },
  { name: 'Sun', stitches: 500 },
];

export const Home: React.FC<HomeProps> = ({ projects, onSelectProject, onOpenProfile }) => {
  const activeProject = projects.find(p => p.status === 'Active') || projects[0];

  return (
    <div className="pb-24 animate-fade-in bg-background min-h-screen">
      <div className="px-6 pt-12 pb-6 flex justify-between items-start">
        <div>
            <p className="text-muted text-sm font-medium mb-1">Good morning,</p>
            <h1 className="text-3xl font-bold text-text">Ready to flow?</h1>
        </div>
        <button 
            onClick={onOpenProfile}
            className="w-10 h-10 rounded-full bg-stone-200 border-2 border-white shadow-sm overflow-hidden active:scale-95 transition-transform"
        >
             <div className="w-full h-full bg-primary flex items-center justify-center text-white font-bold text-xs">S</div>
        </button>
      </div>

      {/* Continue Active Project */}
      <div className="px-6 mb-8">
        <div 
            onClick={() => onSelectProject(activeProject)}
            className="bg-stone-900 rounded-3xl p-6 shadow-xl shadow-stone-200 text-white relative overflow-hidden cursor-pointer active:scale-[0.98] transition-transform group"
        >
            {/* Abstract decoration */}
            <div className="absolute -right-10 -top-10 w-40 h-40 bg-stone-800 rounded-full opacity-50 blur-2xl group-hover:scale-110 transition-transform duration-700"></div>
            
            <div className="flex justify-between items-start relative z-10">
                <div>
                    <span className="inline-flex items-center gap-1 bg-stone-800 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider mb-3">
                        <Clock size={10} /> Continue
                    </span>
                    <h2 className="text-xl font-bold mb-1">{activeProject.title}</h2>
                    <p className="text-stone-400 text-xs">{activeProject.patternName}</p>
                </div>
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center border border-white/10 group-hover:bg-white/20 transition-colors">
                    <ArrowRight size={20} />
                </div>
            </div>
            
            <div className="mt-6 relative z-10">
                <div className="flex justify-between text-xs text-stone-400 mb-2">
                    <span>Row {activeProject.counters[0].value}</span>
                    <span>{activeProject.progress}%</span>
                </div>
                <div className="h-1.5 bg-stone-800 rounded-full">
                    <div className="h-full bg-secondary rounded-full" style={{ width: `${activeProject.progress}%`}}></div>
                </div>
            </div>
        </div>
      </div>

      {/* Stats Chart */}
      <div className="px-6 mb-8">
        <h3 className="text-sm font-bold text-text mb-4">This Week's Flow</h3>
        <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data}>
                    <XAxis 
                        dataKey="name" 
                        tick={{fontSize: 10, fill: '#a8a29e'}} 
                        axisLine={false} 
                        tickLine={false}
                    />
                    <Tooltip 
                        contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                        cursor={{fill: 'transparent'}}
                    />
                    <Bar dataKey="stitches" fill="#a78bfa" radius={[4, 4, 4, 4]} />
                </BarChart>
            </ResponsiveContainer>
        </div>
      </div>

      {/* Inspiration / Community Teaser */}
      <div className="px-6">
        <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-bold text-text">Trending Patterns</h3>
            <span className="text-xs text-primary font-medium">View All</span>
        </div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4">
            {[1, 2, 3].map((i) => (
                <div key={i} className="min-w-[140px] h-[180px] bg-white rounded-2xl border border-stone-100 p-3 flex flex-col shadow-sm active:scale-95 transition-transform cursor-pointer">
                    <div className="flex-1 bg-stone-100 rounded-xl mb-3 bg-cover bg-center" style={{backgroundImage: `url(https://picsum.photos/200/300?random=${i})`}}></div>
                    <p className="text-xs font-bold text-text truncate">Chunky Cardigan</p>
                    <p className="text-[10px] text-muted">by SarahKnits</p>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};