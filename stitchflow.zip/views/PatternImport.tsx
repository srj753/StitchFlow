import React from 'react';
import { Header } from '../components/Header';
import { UploadCloud, Link, FileText, CheckCircle2 } from 'lucide-react';

interface PatternImportProps {
  onBack: () => void;
}

export const PatternImport: React.FC<PatternImportProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-background animate-slide-up">
      <Header title="Import Pattern" onBack={onBack} />
      
      <div className="px-6 mt-8 space-y-6">
        
        <div className="bg-white p-6 rounded-3xl border-2 border-dashed border-primary/30 flex flex-col items-center justify-center gap-4 text-center shadow-sm active:bg-stone-50 transition-colors cursor-pointer">
            <div className="w-16 h-16 bg-violet-50 rounded-full flex items-center justify-center text-primary">
                <UploadCloud size={32} />
            </div>
            <div>
                <h3 className="font-bold text-text">Upload PDF</h3>
                <p className="text-xs text-muted mt-1 max-w-[200px] mx-auto">Tap to browse your files. We'll try to extract the instructions.</p>
            </div>
        </div>

        <div className="relative">
            <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-stone-200"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted">Or import from web</span>
            </div>
        </div>

        <div className="bg-white p-2 rounded-2xl border border-stone-200 shadow-sm flex items-center gap-2">
            <div className="p-3 bg-stone-100 rounded-xl text-stone-500">
                <Link size={20} />
            </div>
            <input 
                placeholder="Paste URL (e.g. Ravelry, Blog)" 
                className="flex-1 outline-none text-sm p-2"
            />
            <button className="bg-stone-900 text-white px-4 py-2 rounded-xl text-xs font-bold">
                Go
            </button>
        </div>

        {/* Extraction Preview Skeleton */}
        <div className="mt-8">
            <h4 className="text-xs font-bold text-muted uppercase tracking-wider mb-4">How it works</h4>
            <div className="space-y-4">
                <div className="flex gap-4">
                    <div className="mt-1 text-primary"><CheckCircle2 size={16} /></div>
                    <div>
                        <p className="text-sm font-bold text-text">Smart Extraction</p>
                        <p className="text-xs text-muted mt-1">We strip away ads and blog stories, leaving just the pattern.</p>
                    </div>
                </div>
                <div className="flex gap-4">
                    <div className="mt-1 text-primary"><CheckCircle2 size={16} /></div>
                    <div>
                        <p className="text-sm font-bold text-text">Interactive Rows</p>
                        <p className="text-xs text-muted mt-1">Tap any row to mark it as complete while you work.</p>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};