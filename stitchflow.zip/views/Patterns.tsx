import React from 'react';
import { Plus, Download, Edit3, Search, BookOpen } from 'lucide-react';

interface PatternsProps {
  onSelectPattern: (p: any) => void;
  onImport: () => void;
  onMaker: () => void;
  onStitchLibrary: () => void;
}

export const Patterns: React.FC<PatternsProps> = ({ onSelectPattern, onImport, onMaker, onStitchLibrary }) => {
  return (
    <div className="pb-24 animate-fade-in min-h-screen bg-background">
       <div className="sticky top-0 bg-background/95 backdrop-blur z-10 px-6 pt-12 pb-2 flex justify-between items-end border-b border-stone-100/50">
        <h1 className="text-3xl font-bold text-text">Patterns</h1>
        <div className="flex gap-2">
            <button onClick={onImport} className="bg-white text-text border border-stone-200 rounded-full p-3 shadow-sm active:bg-stone-50">
                <Download size={20} />
            </button>
            <button onClick={onMaker} className="bg-stone-900 text-white rounded-full p-3 shadow-lg shadow-stone-200 active:scale-95 transition-transform">
                <Plus size={20} />
            </button>
        </div>
      </div>

      <div className="px-6 py-4 space-y-4">
        <div className="bg-white p-3 rounded-2xl border border-stone-200 flex items-center gap-3 shadow-sm">
            <Search size={18} className="text-stone-400" />
            <input placeholder="Search library..." className="flex-1 outline-none text-sm" />
        </div>
        
        {/* Stitch Library Banner */}
        <div 
            onClick={onStitchLibrary}
            className="bg-gradient-to-r from-violet-100 to-fuchsia-100 rounded-3xl p-4 flex items-center justify-between cursor-pointer active:scale-[0.99] transition-transform"
        >
            <div className="flex items-center gap-3">
                <div className="p-3 bg-white/50 rounded-2xl text-primary">
                    <BookOpen size={20} />
                </div>
                <div>
                    <h3 className="text-sm font-bold text-primary">Stitch Library</h3>
                    <p className="text-[10px] text-primary/70">Browse tutorials & guides</p>
                </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-white/50 flex items-center justify-center text-primary text-xs font-bold">
                Go
            </div>
        </div>
      </div>

      <div className="px-6 grid grid-cols-2 gap-4">
        {/* Mock Patterns */}
        {[1, 2, 3, 4, 5].map((i) => (
             <div 
                key={i} 
                onClick={() => onSelectPattern({id: i})}
                className="bg-white p-3 rounded-3xl border border-stone-100 shadow-sm active:scale-[0.98] transition-transform cursor-pointer"
             >
                <div className="aspect-square bg-stone-100 rounded-2xl mb-3 relative overflow-hidden bg-cover bg-center" style={{backgroundImage: `url(https://picsum.photos/300/300?random=${i + 10})`}}>
                     <div className="absolute top-2 right-2 bg-white/80 backdrop-blur px-2 py-1 rounded-lg text-[10px] font-bold">
                        PDF
                     </div>
                </div>
                <h3 className="font-bold text-text text-sm truncate">Granny Square Cardigan</h3>
                <p className="text-[10px] text-muted">Added 2 days ago</p>
             </div>
        ))}
        
        {/* Draft Pattern */}
        <div 
            onClick={onMaker}
            className="bg-stone-50 p-3 rounded-3xl border border-stone-200 border-dashed flex flex-col items-center justify-center gap-2 aspect-square text-muted active:bg-stone-100 cursor-pointer"
        >
            <Edit3 size={24} />
            <span className="text-xs font-medium">Draft New</span>
        </div>
      </div>
    </div>
  );
};
