import React, { useState } from 'react';
import { Header } from '../components/Header';
import { Undo, Redo, Layers, PenTool, Eraser, Grid, Download, Eye, EyeOff } from 'lucide-react';

interface DiagramEditorProps {
  onBack: () => void;
}

export const DiagramEditor: React.FC<DiagramEditorProps> = ({ onBack }) => {
  const [activeTool, setActiveTool] = useState<'pen' | 'eraser' | 'move'>('pen');
  const [showLayers, setShowLayers] = useState(false);

  return (
    <div className="min-h-screen bg-stone-100 animate-slide-up flex flex-col">
      <Header 
        title="Diagram Editor" 
        onBack={onBack} 
        rightAction={<button className="text-primary font-bold text-xs"><Download size={20}/></button>}
      />

      {/* Toolbar */}
      <div className="bg-white p-2 border-b border-stone-200 flex justify-between items-center px-6 shadow-sm z-10">
        <div className="flex gap-1 bg-stone-100 p-1 rounded-xl">
             <button 
                onClick={() => setActiveTool('pen')}
                className={`p-2 rounded-lg ${activeTool === 'pen' ? 'bg-white shadow-sm text-primary' : 'text-stone-400'}`}
             >
                <PenTool size={18} />
             </button>
             <button 
                onClick={() => setActiveTool('eraser')}
                className={`p-2 rounded-lg ${activeTool === 'eraser' ? 'bg-white shadow-sm text-primary' : 'text-stone-400'}`}
             >
                <Eraser size={18} />
             </button>
             <button className="p-2 rounded-lg text-stone-400">
                <Grid size={18} />
             </button>
        </div>
        <div className="flex gap-4">
             <button className="text-stone-400"><Undo size={18} /></button>
             <button className="text-stone-400"><Redo size={18} /></button>
        </div>
      </div>

      {/* Canvas Area */}
      <div className="flex-1 relative overflow-hidden bg-stone-50 cursor-crosshair">
         <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10" 
              style={{backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '20px 20px'}}>
         </div>
         {/* Mock Drawing content */}
         <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border-2 border-dashed border-primary/20 rounded-full flex items-center justify-center">
             <span className="text-xs text-primary/40 font-bold">Start drawing or tap grid mode</span>
         </div>
      </div>

      {/* Layer Drawer (Collapsed) */}
      <div className="bg-white border-t border-stone-200">
          <div className="px-6 py-3 flex justify-between items-center" onClick={() => setShowLayers(!showLayers)}>
              <div className="flex items-center gap-2 text-sm font-bold text-text">
                  <Layers size={18} />
                  Layers (3)
              </div>
              <div className="w-10 h-1 bg-stone-200 rounded-full"></div>
          </div>
          
          {showLayers && (
              <div className="px-6 pb-6 space-y-2 animate-slide-up">
                  <div className="flex items-center gap-3 p-3 bg-stone-50 rounded-xl border border-stone-100">
                      <div className="w-4 h-4 rounded border border-stone-300 bg-white"></div>
                      <span className="text-sm font-medium flex-1">Annotations</span>
                      <button className="text-stone-400"><EyeOff size={16}/></button>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-stone-50 rounded-xl border border-stone-100">
                      <div className="w-4 h-4 rounded border border-stone-300 bg-white"></div>
                      <span className="text-sm font-medium flex-1">Pattern Chart</span>
                      <button className="text-stone-400"><Eye size={16}/></button>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-violet-50 rounded-xl border border-primary/20">
                      <div className="w-4 h-4 rounded border border-primary bg-primary"></div>
                      <span className="text-sm font-bold text-primary flex-1">Background Image</span>
                      <button className="text-primary"><Eye size={16}/></button>
                  </div>
              </div>
          )}
      </div>
    </div>
  );
};
