import React, { useState } from 'react';
import { ArrowLeft, MoreVertical, Mic, Image as ImageIcon, BrainCircuit, Send, Ruler, Sparkles, Pencil, FileText, Globe, Layers, Clock, Plus, Palette, StickyNote } from 'lucide-react';
import { Project, ViewState } from '../types';
import { CounterCard } from '../components/CounterCard';
import { generateCrochetAdvice } from '../services/geminiService';

interface ProjectDetailProps {
  project: Project;
  onBack: () => void;
  onUpdateProject: (p: Project) => void;
  onOpenDiagram: () => void;
}

export const ProjectDetail: React.FC<ProjectDetailProps> = ({ project, onBack, onUpdateProject, onOpenDiagram }) => {
  const [activeTab, setActiveTab] = useState<'track' | 'pattern' | 'studio' | 'ai'>('track');
  const [aiQuery, setAiQuery] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const [patternViewMode, setPatternViewMode] = useState<'smart' | 'web'>('smart');

  const handleCounterUpdate = (id: string, val: number) => {
    const updatedCounters = project.counters.map(c => c.id === id ? { ...c, value: val } : c);
    onUpdateProject({ ...project, counters: updatedCounters, lastUpdated: new Date().toISOString() });
  };

  const handleAskAI = async () => {
    if (!aiQuery.trim()) return;
    setIsThinking(true);
    setAiResponse(null);
    const answer = await generateCrochetAdvice(aiQuery, `Project: ${project.title}, Pattern: ${project.patternName}`);
    setAiResponse(answer);
    setIsThinking(false);
    setAiQuery('');
  };

  // Get Primary Counter for Floating HUD
  const primaryCounter = project.counters.find(c => c.label === 'Row') || project.counters[0];

  return (
    <div className="min-h-screen bg-background pb-24 animate-slide-up flex flex-col">
      {/* Header */}
      <div className="sticky top-0 bg-background/80 backdrop-blur-md z-40 px-6 pt-12 pb-4 flex justify-between items-center border-b border-stone-100">
        <button onClick={onBack} className="p-2 -ml-2 text-text hover:bg-stone-100 rounded-full">
          <ArrowLeft size={24} />
        </button>
        <div className="text-center">
            <h1 className="text-lg font-bold text-text">{project.title}</h1>
            <p className="text-xs text-muted">{project.patternName}</p>
        </div>
        <button className="p-2 -mr-2 text-text hover:bg-stone-100 rounded-full">
          <MoreVertical size={24} />
        </button>
      </div>

      {/* Internal Tabs */}
      <div className="px-6 mt-4 mb-4">
        <div className="flex p-1 bg-stone-100 rounded-2xl">
            {['track', 'pattern', 'studio', 'ai'].map((tab) => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab as any)}
                    className={`flex-1 py-2 text-xs font-medium rounded-xl transition-all ${
                        activeTab === tab ? 'bg-white text-primary shadow-sm' : 'text-muted'
                    }`}
                >
                    {tab === 'ai' ? 'Assistant' : tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
            ))}
        </div>
      </div>

      <div className="flex-1 px-6 space-y-6 overflow-y-auto">
        
        {/* --- TRACK TAB (COMMAND CENTER) --- */}
        {activeTab === 'track' && (
            <>
                <div className="grid grid-cols-2 gap-4">
                    {project.counters.map(counter => (
                        <div key={counter.id} className={project.counters.length === 1 ? "col-span-2" : "col-span-1"}>
                            <CounterCard counter={counter} onUpdate={handleCounterUpdate} />
                        </div>
                    ))}
                </div>
                
                {/* Tools & Yarn Widget */}
                <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white p-4 rounded-3xl border border-stone-100 shadow-sm flex flex-col justify-between h-28">
                         <div className="flex items-center gap-2 text-muted">
                            <Ruler size={16} />
                            <span className="text-xs font-bold uppercase tracking-wider">Hook</span>
                         </div>
                         <div className="text-2xl font-bold text-text">5.0mm</div>
                         <p className="text-[10px] text-muted">Suggested: 4.5mm</p>
                    </div>
                    <div className="bg-white p-4 rounded-3xl border border-stone-100 shadow-sm flex flex-col justify-between h-28">
                         <div className="flex items-center gap-2 text-muted">
                            <Clock size={16} />
                            <span className="text-xs font-bold uppercase tracking-wider">Time</span>
                         </div>
                         <div className="text-2xl font-bold text-text">12h 30m</div>
                         <button className="text-[10px] bg-stone-100 rounded-full py-1 text-center font-medium">View Log</button>
                    </div>
                </div>

                {/* Diagram/Chart Entry */}
                <button 
                    onClick={onOpenDiagram}
                    className="w-full bg-stone-900 text-white p-4 rounded-3xl flex items-center justify-between shadow-lg shadow-stone-200 active:scale-[0.98]"
                >
                    <div className="flex items-center gap-3">
                        <Layers size={20} />
                        <div className="text-left">
                            <p className="font-bold text-sm">Open Diagram</p>
                            <p className="text-[10px] text-stone-400">View stitches or draw notes</p>
                        </div>
                    </div>
                    <ArrowLeft size={16} className="rotate-180" />
                </button>
            </>
        )}

        {/* --- PATTERN TAB (READER + HUD) --- */}
        {activeTab === 'pattern' && (
            <div className="h-full flex flex-col relative">
                 <div className="bg-stone-100 p-1 rounded-xl flex mb-4 flex-shrink-0">
                    <button 
                        onClick={() => setPatternViewMode('smart')}
                        className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${patternViewMode === 'smart' ? 'bg-white shadow-sm text-text' : 'text-muted'}`}
                    >
                        <FileText size={14} /> Smart Text
                    </button>
                    <button 
                        onClick={() => setPatternViewMode('web')}
                        className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${patternViewMode === 'web' ? 'bg-white shadow-sm text-text' : 'text-muted'}`}
                    >
                        <Globe size={14} /> Original PDF
                    </button>
                </div>
                
                <div className="flex-1 bg-white rounded-3xl border border-stone-100 p-4 shadow-sm overflow-y-auto mb-20">
                    {patternViewMode === 'smart' ? (
                        <div className="space-y-4 pb-20">
                            <div className="bg-primary/5 p-4 rounded-2xl border border-primary/10">
                                <h4 className="text-xs font-bold text-primary uppercase mb-2">Current Row: {primaryCounter.value}</h4>
                                <p className="text-sm font-medium text-text">Ch 1, sc in each st around, sl st to join. (48 sts)</p>
                            </div>
                            <div className="opacity-50 pointer-events-none">
                                <p className="text-xs text-muted mb-1">Row {primaryCounter.value + 1}</p>
                                <p className="text-sm text-text">Ch 3 (counts as dc), *2 dc in next st, dc in next 3 sts*, repeat around.</p>
                            </div>
                            <p className="text-xs text-muted text-center pt-8">End of extracted text.</p>
                        </div>
                    ) : (
                         <div className="h-full flex flex-col items-center justify-center text-muted gap-4">
                            <Globe size={48} className="opacity-20" />
                            <p className="text-xs">PDF Viewer / Webview would load here.</p>
                         </div>
                    )}
                </div>

                {/* Floating Counter HUD */}
                <div className="absolute bottom-4 left-0 right-0 px-2">
                    <div className="bg-stone-900/95 backdrop-blur-md p-3 rounded-2xl shadow-xl shadow-stone-300 text-white flex items-center justify-between border border-white/10">
                        <div className="px-3">
                            <p className="text-[10px] font-bold text-stone-400 uppercase">{primaryCounter.label}</p>
                            <p className="text-2xl font-bold font-mono">{primaryCounter.value}</p>
                        </div>
                        <button 
                            onClick={() => handleCounterUpdate(primaryCounter.id, primaryCounter.value + 1)}
                            className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-violet-900/50 active:scale-90 transition-transform"
                        >
                            <Plus size={24} strokeWidth={3} />
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* --- STUDIO TAB (MOODBOARD) --- */}
        {activeTab === 'studio' && (
            <div className="space-y-6 pb-10">
                <div className="bg-white p-4 rounded-3xl shadow-sm border border-stone-100 flex items-center gap-3">
                     <span className="text-xs font-bold uppercase tracking-wider text-muted">Add:</span>
                     <button className="p-2 bg-stone-50 rounded-lg text-primary hover:bg-violet-50"><Palette size={16}/></button>
                     <button className="p-2 bg-stone-50 rounded-lg text-primary hover:bg-violet-50"><ImageIcon size={16}/></button>
                     <button className="p-2 bg-stone-50 rounded-lg text-primary hover:bg-violet-50"><StickyNote size={16}/></button>
                </div>

                {/* Masonry Layout Simulation */}
                <div className="columns-2 gap-4 space-y-4">
                    {/* Swatch */}
                    <div className="break-inside-avoid bg-white p-3 rounded-2xl border border-stone-100 shadow-sm">
                        <div className="h-16 rounded-xl bg-[#8b5cf6] mb-2"></div>
                        <p className="text-[10px] font-mono text-muted">#8B5CF6</p>
                        <p className="text-xs font-bold">Main Color</p>
                    </div>
                    
                    {/* Note */}
                    <div className="break-inside-avoid bg-yellow-50 p-4 rounded-2xl border border-yellow-100 shadow-sm rotate-1">
                        <p className="text-xs font-handwriting text-yellow-900 leading-relaxed">
                            "Make the sleeves wider than the pattern suggests. Maybe add ribbing?"
                        </p>
                    </div>

                    {/* Photo */}
                    <div className="break-inside-avoid bg-white p-2 rounded-2xl border border-stone-100 shadow-sm">
                        <div className="w-full h-32 bg-stone-100 rounded-xl bg-cover bg-center mb-2" style={{backgroundImage: 'url(https://picsum.photos/200/300)'}}></div>
                        <p className="text-xs font-bold px-1">Inspo Pic</p>
                    </div>
                    
                    {/* Project Note */}
                    <div className="break-inside-avoid bg-white p-4 rounded-2xl border border-stone-100 shadow-sm">
                        <div className="flex gap-2 mb-2 items-center text-muted">
                            <Mic size={14} /> <span className="text-[10px]">Voice Memo</span>
                        </div>
                        <div className="h-8 bg-stone-100 rounded-full flex items-center px-3 gap-1">
                            <div className="w-0.5 h-3 bg-stone-400"></div>
                            <div className="w-0.5 h-5 bg-stone-400"></div>
                            <div className="w-0.5 h-2 bg-stone-400"></div>
                            <div className="w-0.5 h-4 bg-stone-400"></div>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* --- AI TAB --- */}
        {activeTab === 'ai' && (
            <div className="bg-white rounded-3xl shadow-sm border border-stone-100 overflow-hidden min-h-[400px] flex flex-col">
                <div className="p-5 bg-gradient-to-br from-violet-50 to-fuchsia-50 border-b border-stone-100">
                    <div className="flex items-center gap-2 text-primary mb-1">
                        <BrainCircuit size={18} />
                        <span className="font-bold text-sm">StitchFlow Assistant</span>
                    </div>
                    <p className="text-xs text-muted">
                        I know about your <b>{project.patternName}</b>. Ask me to explain the next row.
                    </p>
                </div>
                
                <div className="flex-1 p-5 overflow-y-auto max-h-[300px]">
                    {!aiResponse && !isThinking && (
                        <div className="flex flex-col items-center justify-center h-full text-muted opacity-50">
                            <p className="text-xs text-center">Ask: "How do I do a magic ring?" or "Explain row 4"</p>
                        </div>
                    )}
                    {isThinking && (
                        <div className="flex items-center space-x-2 animate-pulse">
                            <div className="w-2 h-2 bg-primary rounded-full"></div>
                            <div className="w-2 h-2 bg-primary rounded-full delay-75"></div>
                            <div className="w-2 h-2 bg-primary rounded-full delay-150"></div>
                        </div>
                    )}
                    {aiResponse && (
                         <div className="text-sm text-text leading-relaxed animate-fade-in bg-stone-50 p-4 rounded-2xl rounded-tl-none">
                            {aiResponse}
                         </div>
                    )}
                </div>

                <div className="p-4 border-t border-stone-100 flex gap-2">
                    <input 
                        value={aiQuery}
                        onChange={(e) => setAiQuery(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAskAI()}
                        placeholder="Ask AI..." 
                        className="flex-1 bg-stone-50 rounded-xl px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                    />
                    <button 
                        onClick={handleAskAI}
                        className="w-10 h-10 bg-primary text-white rounded-xl flex items-center justify-center active:scale-95 transition-transform"
                    >
                        <Send size={18} />
                    </button>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};
