import React from 'react';
import { Header } from '../components/Header';
import { Ruler, Scale, ExternalLink, Calculator } from 'lucide-react';

interface StashDetailProps {
  onBack: () => void;
}

export const StashDetail: React.FC<StashDetailProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-background animate-slide-up pb-10">
      <Header title="Red Heart Super Saver" subtitle="Worsted • Blueberry" onBack={onBack} />
      
      <div className="px-6 mt-6 space-y-6">
        
        {/* Main Info */}
        <div className="flex gap-5 items-start">
            <div className="w-24 h-24 rounded-3xl bg-blue-400 shadow-md"></div>
            <div className="flex-1 space-y-3">
                <div className="bg-white p-3 rounded-2xl border border-stone-100 flex items-center gap-3">
                    <Scale size={18} className="text-stone-400" />
                    <div>
                        <p className="text-[10px] text-muted uppercase font-bold">Weight</p>
                        <p className="text-sm font-bold">Medium (4)</p>
                    </div>
                </div>
                <div className="bg-white p-3 rounded-2xl border border-stone-100 flex items-center gap-3">
                    <Ruler size={18} className="text-stone-400" />
                    <div>
                        <p className="text-[10px] text-muted uppercase font-bold">Quantity</p>
                        <p className="text-sm font-bold">2.5 Skeins (~480m)</p>
                    </div>
                </div>
            </div>
        </div>

        {/* Calculator Stub */}
        <div className="bg-stone-900 rounded-3xl p-6 text-white relative overflow-hidden shadow-xl shadow-stone-200">
            <div className="relative z-10">
                <div className="flex items-center gap-2 mb-4">
                    <Calculator size={20} className="text-secondary" />
                    <h3 className="font-bold text-lg">Yarn Estimator</h3>
                </div>
                <p className="text-sm text-stone-300 mb-6">Will this cover your next blanket?</p>
                
                <div className="bg-white/10 p-3 rounded-xl mb-4 flex justify-between items-center">
                    <span className="text-sm">Select Project Type</span>
                    <span className="text-xs font-bold text-secondary">Baby Blanket</span>
                </div>
                
                <div className="flex justify-between items-end border-t border-white/10 pt-4">
                    <div>
                        <p className="text-[10px] uppercase font-bold text-stone-400">Result</p>
                        <p className="text-lg font-bold text-green-400">You have enough!</p>
                    </div>
                    <span className="text-xs text-stone-400">Needs ~400m</span>
                </div>
            </div>
        </div>

        {/* Linked Projects */}
        <div>
            <h3 className="text-sm font-bold text-text mb-3 ml-1">Used In Projects</h3>
            <div className="bg-white p-4 rounded-3xl border border-stone-100 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-stone-100"></div>
                <div className="flex-1">
                    <p className="font-bold text-sm">Sunny Day Blanket</p>
                    <p className="text-xs text-muted">Active • Used 1.5 skeins</p>
                </div>
                <ExternalLink size={16} className="text-stone-300" />
            </div>
        </div>

      </div>
    </div>
  );
};
