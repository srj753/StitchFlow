import React from 'react';
import { Header } from '../components/Header';
import { ChevronRight, Camera, Ruler, Sparkles } from 'lucide-react';

interface ProjectCreateProps {
  onBack: () => void;
}

export const ProjectCreate: React.FC<ProjectCreateProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-background animate-slide-up pb-10">
      <Header title="New Project" onBack={onBack} />
      
      <div className="px-6 mt-6 space-y-8">
        
        {/* Photo Upload Placeholder */}
        <div className="flex justify-center">
            <div className="w-32 h-32 bg-stone-100 rounded-3xl border-2 border-dashed border-stone-300 flex flex-col items-center justify-center text-muted gap-2 active:bg-stone-200 transition-colors">
                <Camera size={24} />
                <span className="text-[10px] font-medium">Add Cover</span>
            </div>
        </div>

        {/* Form Fields */}
        <div className="space-y-5">
            <div className="space-y-2">
                <label className="text-xs font-bold text-muted uppercase tracking-wider ml-1">Project Details</label>
                <input 
                    type="text" 
                    placeholder="Project Title" 
                    className="w-full bg-white p-4 rounded-2xl border border-stone-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary text-text placeholder:text-stone-300"
                />
                <div className="relative">
                    <input 
                        type="text" 
                        placeholder="Select Pattern (Optional)" 
                        className="w-full bg-white p-4 rounded-2xl border border-stone-200 outline-none focus:border-primary text-text placeholder:text-stone-300"
                    />
                    <div className="absolute right-4 top-4 text-stone-300">
                        <ChevronRight size={20} />
                    </div>
                </div>
            </div>

            <div className="space-y-2">
                 <label className="text-xs font-bold text-muted uppercase tracking-wider ml-1">Tools & Yarn</label>
                 
                 <div className="flex gap-3">
                    <div className="flex-1 bg-white p-4 rounded-2xl border border-stone-200 flex justify-between items-center">
                        <div className="flex items-center gap-3 text-muted">
                            <Ruler size={18} />
                            <span className="text-sm">Hook Size</span>
                        </div>
                        <span className="text-sm font-bold text-text">5.0mm</span>
                    </div>
                 </div>

                 <button className="w-full bg-white p-4 rounded-2xl border border-stone-200 border-dashed text-primary flex items-center justify-center gap-2 font-medium active:bg-violet-50">
                    <Sparkles size={18} />
                    Link Yarn from Stash
                 </button>
            </div>

            <div className="space-y-2">
                 <label className="text-xs font-bold text-muted uppercase tracking-wider ml-1">Counters Setup</label>
                 <div className="bg-white p-4 rounded-2xl border border-stone-200 flex justify-between items-center">
                    <span className="text-sm text-text">Default Counters</span>
                    <div className="flex gap-2">
                        <span className="px-3 py-1 bg-stone-100 rounded-lg text-xs font-medium text-stone-600">Row</span>
                        <span className="px-3 py-1 bg-stone-100 rounded-lg text-xs font-medium text-stone-600">Stitch</span>
                    </div>
                 </div>
            </div>
        </div>

      </div>

      <div className="fixed bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-background to-transparent">
        <button onClick={onBack} className="w-full bg-stone-900 text-white py-4 rounded-2xl font-bold shadow-xl shadow-stone-200 active:scale-[0.98] transition-transform">
            Create Project
        </button>
      </div>
    </div>
  );
};