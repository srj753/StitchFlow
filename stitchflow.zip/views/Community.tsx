import React, { useState } from 'react';
import { Heart, MessageCircle, Share2, Award, Pin, Users, ArrowRight } from 'lucide-react';

export const Community: React.FC = () => {
  const [tab, setTab] = useState<'inspiration' | 'testers'>('inspiration');

  return (
    <div className="pb-24 animate-fade-in min-h-screen bg-background">
      <div className="sticky top-0 bg-background/95 backdrop-blur z-10 px-6 pt-12 pb-4 border-b border-stone-100">
        <h1 className="text-3xl font-bold text-text mb-4">Community</h1>
        <div className="flex bg-stone-100 p-1 rounded-2xl">
            <button 
                onClick={() => setTab('inspiration')}
                className={`flex-1 py-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${tab === 'inspiration' ? 'bg-white shadow-sm text-text' : 'text-muted'}`}
            >
                <Pin size={14} /> Inspiration
            </button>
            <button 
                onClick={() => setTab('testers')}
                className={`flex-1 py-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${tab === 'testers' ? 'bg-white shadow-sm text-text' : 'text-muted'}`}
            >
                <Users size={14} /> Testers
            </button>
        </div>
      </div>

      <div className="px-4 pt-6">
        {tab === 'inspiration' ? (
             // Pinterest Style Masonry Grid
             <div className="columns-2 gap-4 space-y-4">
                 {[1, 2, 3, 4, 5, 6].map((i) => (
                    <div key={i} className="break-inside-avoid bg-white rounded-2xl border border-stone-100 shadow-sm overflow-hidden group hover:shadow-md transition-all">
                        <div className="relative">
                            <img src={`https://picsum.photos/300/${200 + (i % 3) * 100}?random=${i}`} className="w-full object-cover" alt="Community Post" />
                            <div className="absolute top-2 right-2 bg-black/50 text-white px-2 py-1 rounded-full text-[10px] font-bold backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity">
                                <Heart size={10} className="inline mr-1" /> 24
                            </div>
                        </div>
                        <div className="p-3">
                            <p className="text-xs font-bold text-text line-clamp-2">Summer Cardigan in Cotton</p>
                            <div className="flex items-center gap-2 mt-2">
                                <div className="w-5 h-5 rounded-full bg-stone-200"></div>
                                <span className="text-[10px] text-muted">sarah_knits</span>
                            </div>
                        </div>
                    </div>
                 ))}
             </div>
        ) : (
            // Testers Board
            <div className="space-y-4 px-2">
                 {[1, 2].map((i) => (
                    <div key={i} className="bg-white rounded-3xl border border-stone-100 shadow-sm p-5 relative overflow-hidden active:scale-[0.99] transition-transform">
                        <div className="absolute top-0 right-0 bg-secondary/10 text-primary px-4 py-1.5 rounded-bl-2xl text-[10px] font-bold uppercase tracking-wider">
                            Open Call
                        </div>
                        
                        <div className="flex gap-4 mb-4 mt-2">
                            <div className="w-20 h-20 rounded-2xl bg-stone-100 bg-cover bg-center shadow-inner" style={{backgroundImage: `url(https://picsum.photos/200/200?random=${i+50})`}}></div>
                            <div className="flex-1">
                                <h3 className="font-bold text-text text-lg leading-tight mb-1">Dragon Scale Gloves</h3>
                                <p className="text-xs text-muted mb-2">by @mystic_yarns</p>
                                <div className="flex flex-wrap gap-2">
                                    <span className="bg-stone-50 px-2 py-1 rounded-lg text-[10px] font-medium text-muted border border-stone-100">Intermediate</span>
                                    <span className="bg-stone-50 px-2 py-1 rounded-lg text-[10px] font-medium text-muted border border-stone-100">3.5mm</span>
                                </div>
                            </div>
                        </div>
                        
                        <div className="bg-stone-50 rounded-xl p-3 mb-4 grid grid-cols-2 gap-2">
                            <div>
                                <p className="text-[10px] text-stone-400 uppercase font-bold">Deadline</p>
                                <p className="text-xs font-semibold text-text">Oct 20, 2024</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-stone-400 uppercase font-bold">Yarn Support</p>
                                <p className="text-xs font-semibold text-text">Digital Code</p>
                            </div>
                        </div>

                        <button className="w-full py-3.5 bg-stone-900 text-white rounded-xl text-xs font-bold shadow-lg shadow-stone-200 flex items-center justify-center gap-2">
                            Apply to Test <ArrowRight size={14} />
                        </button>
                    </div>
                ))}
            </div>
        )}
      </div>
    </div>
  );
};
