import React from 'react';
import { Plus, Search, Filter } from 'lucide-react';

interface StashProps {
  onAdd: () => void;
  onDetail: (id: string) => void;
}

export const Stash: React.FC<StashProps> = ({ onAdd, onDetail }) => {
  return (
    <div className="pb-24 animate-fade-in min-h-screen bg-background">
      <div className="sticky top-0 bg-background/95 backdrop-blur z-10 px-6 pt-12 pb-2 flex justify-between items-end border-b border-stone-100/50">
        <h1 className="text-3xl font-bold text-text">Stash</h1>
        <button 
          onClick={onAdd}
          className="bg-stone-900 text-white rounded-full p-3 shadow-lg shadow-stone-200 active:scale-95 transition-transform"
        >
          <Plus size={20} />
        </button>
      </div>

      <div className="px-6 py-4 flex gap-2">
        <div className="bg-white flex-1 p-3 rounded-2xl border border-stone-200 flex items-center gap-3 shadow-sm">
            <Search size={18} className="text-stone-400" />
            <input placeholder="Search yarn..." className="flex-1 outline-none text-sm" />
        </div>
        <button className="bg-white p-3 rounded-2xl border border-stone-200 shadow-sm text-stone-500 hover:text-primary active:bg-stone-50">
            <Filter size={18} />
        </button>
      </div>

      <div className="px-6 space-y-3">
        {[1, 2, 3, 4].map((i) => (
             <div 
                key={i} 
                onClick={() => onDetail(i.toString())}
                className="bg-white p-4 rounded-3xl border border-stone-100 shadow-sm flex items-center gap-4 active:scale-[0.99] transition-transform cursor-pointer"
             >
                <div className="w-14 h-14 rounded-full bg-stone-100 border-2 border-white shadow-sm relative">
                     {/* Color indicator */}
                     <div className={`absolute bottom-0 right-0 w-5 h-5 rounded-full border-2 border-white ${i % 2 === 0 ? 'bg-blue-400' : 'bg-pink-300'}`}></div>
                </div>
                <div className="flex-1">
                    <h3 className="font-bold text-text text-sm">Red Heart Super Saver</h3>
                    <p className="text-xs text-muted">Worsted • {i % 2 === 0 ? 'Blueberry' : 'Petal Pink'}</p>
                </div>
                <div className="text-right">
                    <p className="font-bold text-text text-sm">{i + 1} skeins</p>
                    <p className="text-[10px] text-muted">~{200 * i}m</p>
                </div>
             </div>
        ))}
      </div>
    </div>
  );
};
