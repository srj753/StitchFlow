import React from 'react';
import { Settings, Award, Heart, Sparkles, PenTool } from 'lucide-react';

interface ProfileProps {
  onBack: () => void;
  onSettings: () => void;
}

export const Profile: React.FC<ProfileProps> = ({ onBack, onSettings }) => {
  return (
    <div className="min-h-screen bg-background animate-slide-up pb-24">
       <div className="sticky top-0 z-40 px-6 pt-12 pb-4 flex justify-between items-center bg-background/95 backdrop-blur-md border-b border-stone-100/50">
            <div className="text-xl font-bold text-text">My Studio</div>
            <button 
                onClick={onSettings}
                className="p-2 bg-stone-100 rounded-full text-stone-600 active:bg-stone-200 transition-colors"
            >
                <Settings size={20} />
            </button>
       </div>

       <div className="px-6 mt-6 mb-8 flex items-center gap-5">
            <div className="w-20 h-20 rounded-full bg-primary text-white flex items-center justify-center text-2xl font-bold shadow-lg shadow-violet-200">
                S
            </div>
            <div>
                <h2 className="text-xl font-bold text-text">StitchFlow User</h2>
                <p className="text-xs text-muted">Member since 2024</p>
                <div className="flex gap-2 mt-2">
                    <span className="bg-secondary/20 text-primary px-2 py-0.5 rounded-full text-[10px] font-bold">Pro Member</span>
                </div>
            </div>
       </div>

       {/* Stats Grid */}
       <div className="px-6 grid grid-cols-2 gap-3 mb-8">
            <div className="bg-white p-4 rounded-3xl border border-stone-100 shadow-sm">
                <div className="text-2xl font-bold text-text mb-1">12</div>
                <div className="text-[10px] text-muted font-bold uppercase tracking-wider">Projects Finished</div>
            </div>
            <div className="bg-white p-4 rounded-3xl border border-stone-100 shadow-sm">
                <div className="text-2xl font-bold text-text mb-1">14k</div>
                <div className="text-[10px] text-muted font-bold uppercase tracking-wider">Stitches Logged</div>
            </div>
       </div>

       <div className="px-6 space-y-2">
            <h3 className="text-sm font-bold text-text mb-2">My Collection</h3>
            
            <div className="bg-white p-4 rounded-2xl border border-stone-100 flex justify-between items-center active:scale-[0.99] transition-transform cursor-pointer">
                <div className="flex items-center gap-3">
                    <Heart size={18} className="text-stone-400" />
                    <span className="text-sm font-medium">Liked Patterns</span>
                </div>
                <span className="text-stone-300">12</span>
            </div>
            
            <div className="bg-white p-4 rounded-2xl border border-stone-100 flex justify-between items-center active:scale-[0.99] transition-transform cursor-pointer">
                <div className="flex items-center gap-3">
                    <Sparkles size={18} className="text-stone-400" />
                    <span className="text-sm font-medium">My Moodboards</span>
                </div>
                <span className="text-stone-300">4</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-100 flex justify-between items-center active:scale-[0.99] transition-transform cursor-pointer">
                <div className="flex items-center gap-3">
                    <PenTool size={18} className="text-stone-400" />
                    <span className="text-sm font-medium">My Sketches</span>
                </div>
                <span className="text-stone-300">8</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-100 flex justify-between items-center active:scale-[0.99] transition-transform cursor-pointer">
                <div className="flex items-center gap-3">
                    <Award size={18} className="text-stone-400" />
                    <span className="text-sm font-medium">Achievements</span>
                </div>
                <span className="text-stone-300">5/20</span>
            </div>
       </div>
    </div>
  );
};
