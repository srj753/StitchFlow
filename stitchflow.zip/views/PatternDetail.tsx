import React, { useState } from 'react';
import { Header } from '../components/Header';
import { FileText, Globe, Layers, Eye } from 'lucide-react';

interface PatternDetailProps {
  onBack: () => void;
}

export const PatternDetail: React.FC<PatternDetailProps> = ({ onBack }) => {
  const [viewMode, setViewMode] = useState<'text' | 'webview'>('text');

  return (
    <div className="min-h-screen bg-background animate-slide-up flex flex-col">
      <Header 
        title="Granny Square Cardigan" 
        subtitle="Imported from Ravelry"
        onBack={onBack} 
        rightAction={<button className="text-primary text-xs font-bold">Edit</button>}
      />

      {/* View Toggle */}
      <div className="px-6 py-4">
        <div className="bg-stone-100 p-1 rounded-xl flex">
            <button 
                onClick={() => setViewMode('text')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${viewMode === 'text' ? 'bg-white shadow-sm text-text' : 'text-muted'}`}
            >
                <FileText size={14} /> Smart View
            </button>
            <button 
                onClick={() => setViewMode('webview')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${viewMode === 'webview' ? 'bg-white shadow-sm text-text' : 'text-muted'}`}
            >
                <Globe size={14} /> Original
            </button>
        </div>
      </div>

      <div className="flex-1 px-6 overflow-y-auto pb-24">
         {viewMode === 'text' ? (
             <div className="space-y-6">
                <div className="bg-white p-5 rounded-3xl border border-stone-100 shadow-sm">
                    <h3 className="font-bold text-text mb-4 border-b border-stone-100 pb-2">Materials Needed</h3>
                    <ul className="space-y-2 text-sm text-muted">
                        <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-primary"></div> 5mm Hook</li>
                        <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-primary"></div> 400g Worsted Yarn</li>
                    </ul>
                </div>

                {/* Simulated Parsed Instructions */}
                <div className="space-y-4">
                    <div className="flex items-center gap-2 text-xs font-bold text-muted uppercase tracking-wider">
                        <span>Foundation</span>
                    </div>
                    <div className="bg-white p-5 rounded-3xl border border-stone-100 shadow-sm relative overflow-hidden">
                        <div className="absolute left-0 top-0 bottom-0 w-1 bg-secondary"></div>
                        <p className="text-text leading-relaxed text-sm">
                            <span className="font-bold text-primary mr-1">R1:</span> 
                            Chain 4, slip stitch into the first chain to form a ring. Ch 3 (counts as first dc).
                        </p>
                    </div>
                    <div className="bg-white p-5 rounded-3xl border border-stone-100 shadow-sm relative opacity-60">
                        <div className="absolute left-0 top-0 bottom-0 w-1 bg-stone-200"></div>
                        <p className="text-text leading-relaxed text-sm">
                            <span className="font-bold text-stone-400 mr-1">R2:</span> 
                            2 dc into ring, ch 2, *3 dc into ring, ch 2* repeat 3 times. Join with sl st.
                        </p>
                    </div>
                </div>
             </div>
         ) : (
             <div className="h-full bg-white rounded-3xl border border-stone-200 flex flex-col items-center justify-center text-muted gap-4">
                <Globe size={48} className="opacity-20" />
                <p className="text-xs">Webview would load original PDF/URL here.</p>
             </div>
         )}
      </div>

      <div className="p-6 border-t border-stone-100 bg-background">
        <button className="w-full bg-stone-900 text-white py-4 rounded-2xl font-bold shadow-lg shadow-stone-200 active:scale-[0.98]">
            Start Project with this Pattern
        </button>
      </div>
    </div>
  );
};