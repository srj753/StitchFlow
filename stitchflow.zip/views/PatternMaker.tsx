import React from 'react';
import { Header } from '../components/Header';
import { GripVertical, Plus, Type, Image as ImageIcon, Save, List } from 'lucide-react';

interface PatternMakerProps {
  onBack: () => void;
}

export const PatternMaker: React.FC<PatternMakerProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-background animate-slide-up pb-24">
      <Header 
        title="New Pattern" 
        subtitle="Drafting..."
        onBack={onBack} 
        rightAction={<button className="bg-primary text-white p-2 rounded-lg text-xs font-bold flex items-center gap-1 shadow-sm"><Save size={14} /> Save</button>} 
      />
      
      <div className="px-6 py-6 space-y-6">
        
        {/* Metadata */}
        <div className="bg-white p-4 rounded-3xl border border-stone-100 space-y-3 shadow-sm">
            <input 
                placeholder="Pattern Title" 
                className="text-xl font-bold bg-transparent outline-none placeholder:text-stone-300 w-full"
            />
            <div className="flex gap-2">
                <span className="px-3 py-1 bg-stone-50 rounded-lg text-xs text-muted border border-stone-100">Category...</span>
                <span className="px-3 py-1 bg-stone-50 rounded-lg text-xs text-muted border border-stone-100">Difficulty...</span>
            </div>
        </div>

        {/* Builder Area */}
        <div className="space-y-4">
            <div className="flex justify-between items-center px-1">
                <h3 className="text-xs font-bold text-muted uppercase tracking-wider">Instructions</h3>
                <button className="text-primary text-xs font-bold flex items-center gap-1"><List size={14}/> Reorder</button>
            </div>

            <div className="space-y-3">
                {/* Section Block */}
                <div className="bg-white rounded-3xl shadow-sm border border-stone-100 overflow-hidden">
                    <div className="bg-stone-50 px-4 py-2 border-b border-stone-100 flex justify-between items-center">
                        <span className="text-xs font-bold text-text uppercase">Section 1: Body</span>
                        <button className="text-stone-400 hover:text-primary"><GripVertical size={14} /></button>
                    </div>
                    
                    {[1, 2, 3].map((row) => (
                        <div key={row} className="p-4 border-b border-stone-100 flex gap-3 items-start group hover:bg-stone-50/50 transition-colors">
                            <div className="w-6 text-xs font-bold text-primary pt-1">{row}.</div>
                            <div className="flex-1 text-sm text-text">
                                {row === 1 ? 'Ch 24, join with sl st.' : 'Sc in each st around (24).'}
                            </div>
                        </div>
                    ))}
                    
                    {/* Add Row Input */}
                    <div className="p-3 bg-stone-50 flex gap-2">
                        <input placeholder="Next step instructions..." className="flex-1 bg-white border border-stone-200 rounded-xl px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-primary/20" />
                        <button className="bg-stone-900 text-white w-9 h-9 rounded-xl flex items-center justify-center shadow-md">
                            <Plus size={16} />
                        </button>
                    </div>
                </div>

                {/* Add Block Button */}
                <button className="w-full py-4 border-2 border-dashed border-stone-200 rounded-3xl text-stone-400 font-medium text-sm flex items-center justify-center gap-2 hover:bg-stone-50 hover:border-primary/30 hover:text-primary transition-all">
                    <Plus size={18} /> Add New Section
                </button>
            </div>
        </div>

      </div>
    </div>
  );
};
