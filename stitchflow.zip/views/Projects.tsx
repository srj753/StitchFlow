import React from 'react';
import { Plus, MoreHorizontal } from 'lucide-react';
import { Project } from '../types';

interface ProjectsProps {
  projects: Project[];
  onSelectProject: (p: Project) => void;
  onCreateProject: () => void;
}

export const Projects: React.FC<ProjectsProps> = ({ projects, onSelectProject, onCreateProject }) => {
  return (
    <div className="pb-24 animate-fade-in min-h-screen bg-background">
      <div className="sticky top-0 bg-background/95 backdrop-blur z-10 px-6 pt-12 pb-6 flex justify-between items-end border-b border-stone-100">
        <h1 className="text-3xl font-bold text-text">Projects</h1>
        <button 
          onClick={onCreateProject}
          className="bg-stone-900 text-white rounded-full p-3 shadow-lg shadow-stone-200 active:scale-95 transition-transform"
        >
          <Plus size={20} />
        </button>
      </div>

      {/* Filter Pills */}
      <div className="px-6 my-6 flex gap-3 overflow-x-auto no-scrollbar">
        <button className="px-5 py-2 bg-stone-900 text-white text-xs font-medium rounded-full whitespace-nowrap shadow-sm">All Projects</button>
        <button className="px-5 py-2 bg-white text-muted border border-stone-200 text-xs font-medium rounded-full whitespace-nowrap">WIPs</button>
        <button className="px-5 py-2 bg-white text-muted border border-stone-200 text-xs font-medium rounded-full whitespace-nowrap">Finished</button>
        <button className="px-5 py-2 bg-white text-muted border border-stone-200 text-xs font-medium rounded-full whitespace-nowrap">Favorites</button>
      </div>

      <div className="px-6 space-y-4">
        {projects.map((project) => (
          <div 
            key={project.id}
            onClick={() => onSelectProject(project)}
            className="bg-white p-4 rounded-3xl shadow-sm border border-stone-100 active:scale-[0.99] transition-transform cursor-pointer relative overflow-hidden group"
          >
            <div className="flex gap-4 relative z-10">
              <div className="w-20 h-24 bg-stone-100 rounded-2xl bg-cover bg-center relative overflow-hidden shadow-inner" style={{backgroundImage: `url(${project.thumbnailUrl})`}}>
                  {!project.thumbnailUrl && <div className="absolute inset-0 flex items-center justify-center text-stone-300"><Plus size={20} className="rotate-45"/></div>}
              </div>
              <div className="flex-1 flex flex-col justify-between py-1">
                <div>
                    <div className="flex justify-between items-start">
                        <h3 className="font-bold text-text line-clamp-1">{project.title}</h3>
                        <button className="text-stone-300 hover:text-stone-600 p-1 -mr-2">
                            <MoreHorizontal size={16} />
                        </button>
                    </div>
                    <p className="text-xs text-muted mt-1">{project.patternName}</p>
                </div>
                <div>
                    <div className="flex justify-between text-xs mb-1.5">
                        <span className="font-medium text-primary">{project.progress}%</span>
                        <span className="text-stone-400">Row {project.counters.find(c => c.label === 'Row')?.value || 0}</span>
                    </div>
                    <div className="h-1.5 bg-stone-100 rounded-full overflow-hidden">
                        <div className="h-full bg-secondary w-1/2 rounded-full"></div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};